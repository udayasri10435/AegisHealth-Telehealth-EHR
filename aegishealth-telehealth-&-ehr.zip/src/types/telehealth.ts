/**
 * AegisHealth HIPAA-Compliant Telehealth & EHR Platform
 * Core Data Models & Type Definitions
 */

export type UserRole = 'physician' | 'patient' | 'admin' | 'compliance_officer';

export interface UserSession {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  title: string;
  npi?: string;
  dea?: string;
  organization: string;
}

export interface PatientVitals {
  heartRate: number; // bpm
  bloodPressureSys: number; // mmHg
  bloodPressureDia: number; // mmHg
  oxygenSaturation: number; // %
  respiratoryRate: number; // breaths/min
  temperature: number; // deg F
  bmi: number;
  measuredAt: string;
}

export interface PatientAllergy {
  substance: string;
  reaction: string;
  severity: 'mild' | 'moderate' | 'severe';
}

export interface PatientCondition {
  id: string;
  code: string; // ICD-10
  name: string;
  onset: string;
  status: 'active' | 'resolved' | 'managed';
}

export interface PatientRecord {
  id: string;
  mrn: string; // Medical Record Number
  firstName: string;
  lastName: string;
  dob: string;
  gender: 'female' | 'male' | 'other';
  bloodType: string;
  phone: string;
  email: string;
  address: string;
  ssnMasked: string; // e.g. ***-**-4921
  allergies: PatientAllergy[];
  conditions: PatientCondition[];
  vitals: PatientVitals;
  insurancePayerId: string;
  encryptedPhiHash?: string;
  lastVisitDate?: string;
}

export interface ProviderRecord {
  id: string;
  name: string;
  title: string;
  specialty: string;
  npi: string; // National Provider Identifier (10 digits)
  dea: string; // Drug Enforcement Administration #
  stateLicense: string;
  email: string;
  phone: string;
  consultFee: number;
  rating: number;
  availableDays: string[];
}

export type AppointmentStatus = 'scheduled' | 'waiting' | 'in_call' | 'completed' | 'cancelled';

export interface AppointmentRecord {
  id: string;
  patientId: string;
  patientName: string;
  providerId: string;
  providerName: string;
  dateTime: string;
  durationMinutes: number;
  status: AppointmentStatus;
  chiefComplaint: string;
  triageUrgency: 'routine' | 'moderate' | 'urgent';
  symptoms: string[];
  intakeCompleted: boolean;
  hipaaConsentSigned: boolean;
  clinicalNotes?: ClinicalSoapNote;
  roomId?: string;
}

export interface ClinicalSoapNote {
  id: string;
  appointmentId: string;
  providerId: string;
  timestamp: string;
  subjective: string;
  objective: string;
  assessment: string;
  plan: string;
  icd10Diagnosis: string;
  signedByNpi: string;
}

export type DeaSchedule = 'Non-Controlled' | 'Schedule II' | 'Schedule III' | 'Schedule IV' | 'Schedule V';

export interface PrescriptionRecord {
  id: string;
  rxNumber: string;
  patientId: string;
  patientName: string;
  providerId: string;
  providerName: string;
  medicationName: string;
  rxNormCode: string;
  dosage: string;
  frequency: string;
  route: string; // e.g. Oral, Topical
  quantity: number;
  refills: number;
  deaSchedule: DeaSchedule;
  daysSupply: number;
  pharmacyId: string;
  pharmacyName: string;
  status: 'draft' | 'signed' | 'transmitted' | 'dispensed' | 'cancelled';
  interactionWarnings: string[];
  digitalSignature?: {
    signedAt: string;
    signedByNpi: string;
    deaVerified: boolean;
    sha256Certificate: string;
    algorithm: string;
  };
  writtenDate: string;
}

export interface PharmacyRecord {
  id: string;
  name: string;
  ncpdpId: string;
  address: string;
  phone: string;
  is24Hour: boolean;
  surescriptsConnected: boolean;
}

export interface InsurancePolicy {
  id: string;
  patientId: string;
  payerId: string;
  payerName: string;
  planType: 'PPO' | 'HMO' | 'POS' | 'HDHP' | 'Medicare Part B';
  policyNumber: string;
  groupNumber: string;
  subscriberName: string;
  status: 'active' | 'inactive' | 'pending_verification';
  effectiveDate: string;
  expirationDate: string;
  copayPrimary: number;
  copaySpecialist: number;
  copayTelehealth: number;
  deductibleAnnual: number;
  deductibleMet: number;
  outOfPocketMax: number;
  outOfPocketCurrent: number;
  priorAuthRequired: boolean;
  lastVerifiedTimestamp: string;
}

export type AuditAction = 
  | 'PHI_READ'
  | 'PHI_UPDATE'
  | 'E_PRESCRIBE_SIGN'
  | 'CONSULT_START'
  | 'CONSULT_END'
  | 'INSURANCE_270_QUERY'
  | 'FHIR_EXPORT'
  | 'HL7_TRANSMIT'
  | 'KEY_ROTATION'
  | 'BAA_SIGNED'
  | 'BREAK_GLASS_ACCESS';

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  userId: string;
  userRole: UserRole;
  action: AuditAction;
  resourceType: string;
  resourceId: string;
  patientId?: string;
  patientMrn?: string;
  details: string;
  ipAddress: string;
  userAgent: string;
  status: 'success' | 'failure' | 'break_glass_alert';
  prevHash: string;
  currentHash: string;
}

export interface BAARecord {
  id: string;
  vendorName: string;
  serviceCategory: string; // e.g. Cloud Infrastructure, WebRTC Media Server, Clearinghouse
  status: 'active' | 'pending_signature' | 'review_required' | 'expired';
  executedDate: string;
  expiryDate: string;
  coveredServices: string[];
  signatoryName: string;
  signatoryTitle: string;
  sha256Seal: string;
  hhsBreachProtocolHours: number; // e.g. 60 days standard or 24-72 hours contractual
}

export interface BreakGlassRequest {
  id: string;
  userId: string;
  userName: string;
  patientId: string;
  patientName: string;
  clinicalReason: string;
  emergencyCategory: 'life_threatening' | 'unconscious_patient' | 'system_override' | 'code_blue';
  timestamp: string;
  acknowledged: boolean;
}
