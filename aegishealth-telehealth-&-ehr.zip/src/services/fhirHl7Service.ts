/**
 * FHIR R4 & HL7 v2 Integration Engine
 * Provides compliant healthcare interoperability:
 * - HL7 FHIR Release 4 standard resource models (Patient, Encounter, Observation, Condition, MedicationRequest)
 * - HL7 v2.5.1 pipe-and-hat message formatter & parser (MSH, PID, PV1, OBX, DG1)
 * - Validation, export, and bundle generation
 */

import { PatientRecord, AppointmentRecord, PrescriptionRecord, ProviderRecord } from '../types/telehealth';

/**
 * Generate a standard FHIR R4 Patient resource
 */
export function generateFhirPatient(patient: PatientRecord) {
  return {
    resourceType: 'Patient',
    id: patient.id,
    identifier: [
      {
        use: 'usual',
        type: {
          coding: [
            {
              system: 'http://terminology.hl7.org/CodeSystem/v2-0203',
              code: 'MR',
              display: 'Medical Record Number',
            },
          ],
        },
        system: 'urn:oid:2.16.840.1.113883.4.3.99',
        value: patient.mrn,
      },
      {
        use: 'official',
        type: {
          coding: [
            {
              system: 'http://terminology.hl7.org/CodeSystem/v2-0203',
              code: 'SS',
              display: 'Social Security Number',
            },
          ],
        },
        value: patient.ssnMasked,
      },
    ],
    active: true,
    name: [
      {
        use: 'official',
        family: patient.lastName,
        given: [patient.firstName],
      },
    ],
    telecom: [
      {
        system: 'phone',
        value: patient.phone,
        use: 'mobile',
      },
      {
        system: 'email',
        value: patient.email,
        use: 'home',
      },
    ],
    gender: patient.gender,
    birthDate: patient.dob,
    address: [
      {
        use: 'home',
        line: [patient.address],
        city: 'Metropolis',
        state: 'NY',
        postalCode: '10001',
        country: 'USA',
      },
    ],
  };
}

/**
 * Generate FHIR R4 Observation resources for Vitals
 */
export function generateFhirVitalObservations(patient: PatientRecord) {
  const v = patient.vitals;
  const time = v.measuredAt;

  return [
    {
      resourceType: 'Observation',
      id: `obs-hr-${patient.id}`,
      status: 'final',
      category: [
        {
          coding: [
            {
              system: 'http://terminology.hl7.org/CodeSystem/observation-category',
              code: 'vital-signs',
              display: 'Vital Signs',
            },
          ],
        },
      ],
      code: {
        coding: [
          {
            system: 'http://loinc.org',
            code: '8867-4',
            display: 'Heart rate',
          },
        ],
      },
      subject: { reference: `Patient/${patient.id}`, display: `${patient.firstName} ${patient.lastName}` },
      effectiveDateTime: time,
      valueQuantity: {
        value: v.heartRate,
        unit: 'beats/min',
        system: 'http://unitsofmeasure.org',
        code: '/min',
      },
    },
    {
      resourceType: 'Observation',
      id: `obs-bp-${patient.id}`,
      status: 'final',
      category: [
        {
          coding: [
            {
              system: 'http://terminology.hl7.org/CodeSystem/observation-category',
              code: 'vital-signs',
              display: 'Vital Signs',
            },
          ],
        },
      ],
      code: {
        coding: [
          {
            system: 'http://loinc.org',
            code: '85354-9',
            display: 'Blood pressure panel with all children optional',
          },
        ],
      },
      subject: { reference: `Patient/${patient.id}`, display: `${patient.firstName} ${patient.lastName}` },
      effectiveDateTime: time,
      component: [
        {
          code: {
            coding: [{ system: 'http://loinc.org', code: '8480-6', display: 'Systolic blood pressure' }],
          },
          valueQuantity: { value: v.bloodPressureSys, unit: 'mmHg', system: 'http://unitsofmeasure.org', code: 'mm[Hg]' },
        },
        {
          code: {
            coding: [{ system: 'http://loinc.org', code: '8462-4', display: 'Diastolic blood pressure' }],
          },
          valueQuantity: { value: v.bloodPressureDia, unit: 'mmHg', system: 'http://unitsofmeasure.org', code: 'mm[Hg]' },
        },
      ],
    },
    {
      resourceType: 'Observation',
      id: `obs-spo2-${patient.id}`,
      status: 'final',
      category: [
        {
          coding: [
            {
              system: 'http://terminology.hl7.org/CodeSystem/observation-category',
              code: 'vital-signs',
              display: 'Vital Signs',
            },
          ],
        },
      ],
      code: {
        coding: [
          {
            system: 'http://loinc.org',
            code: '2708-6',
            display: 'Oxygen saturation in Arterial blood by Pulse oximetry',
          },
        ],
      },
      subject: { reference: `Patient/${patient.id}`, display: `${patient.firstName} ${patient.lastName}` },
      effectiveDateTime: time,
      valueQuantity: {
        value: v.oxygenSaturation,
        unit: '%',
        system: 'http://unitsofmeasure.org',
        code: '%',
      },
    },
  ];
}

/**
 * Generate FHIR R4 Bundle
 */
export function generateFhirBundle(
  patient: PatientRecord,
  appointments: AppointmentRecord[],
  prescriptions: PrescriptionRecord[]
) {
  const patientResource = generateFhirPatient(patient);
  const vitalsResources = generateFhirVitalObservations(patient);

  const conditionResources = patient.conditions.map(c => ({
    resourceType: 'Condition',
    id: `cond-${c.id}`,
    clinicalStatus: {
      coding: [
        {
          system: 'http://terminology.hl7.org/CodeSystem/condition-clinical',
          code: c.status,
        },
      ],
    },
    code: {
      coding: [
        {
          system: 'http://hl7.org/fhir/sid/icd-10-cm',
          code: c.code,
          display: c.name,
        },
      ],
    },
    subject: { reference: `Patient/${patient.id}` },
    recordedDate: c.onset,
  }));

  const medicationResources = prescriptions
    .filter(p => p.patientId === patient.id)
    .map(p => ({
      resourceType: 'MedicationRequest',
      id: `rx-${p.id}`,
      status: p.status === 'signed' || p.status === 'transmitted' ? 'active' : 'draft',
      intent: 'order',
      medicationCodeableConcept: {
        coding: [
          {
            system: 'http://www.nlm.nih.gov/research/umls/rxnorm',
            code: p.rxNormCode,
            display: p.medicationName,
          },
        ],
      },
      subject: { reference: `Patient/${patient.id}` },
      authoredOn: p.writtenDate,
      dosageInstruction: [
        {
          text: `${p.dosage} - ${p.frequency}`,
          route: { text: p.route },
        },
      ],
      dispenseRequest: {
        numberOfRepeatsAllowed: p.refills,
        quantity: { value: p.quantity, unit: 'doses' },
        expectedSupplyDuration: { value: p.daysSupply, unit: 'days' },
      },
    }));

  const entries = [
    { fullUrl: `urn:uuid:${patientResource.id}`, resource: patientResource },
    ...vitalsResources.map(r => ({ fullUrl: `urn:uuid:${r.id}`, resource: r })),
    ...conditionResources.map(r => ({ fullUrl: `urn:uuid:${r.id}`, resource: r })),
    ...medicationResources.map(r => ({ fullUrl: `urn:uuid:${r.id}`, resource: r })),
  ];

  return {
    resourceType: 'Bundle',
    id: `bundle-aegis-${patient.id}`,
    type: 'collection',
    timestamp: new Date().toISOString(),
    total: entries.length,
    entry: entries,
  };
}

/**
 * Generate HL7 v2.5.1 Pipe & Hat ADT_A01 (Admit / Visit Notification) or SIU_S12 (Appointment Notification)
 */
export function generateHL7Message(params: {
  patient: PatientRecord;
  provider: ProviderRecord;
  appointment?: AppointmentRecord;
  messageType?: 'ADT^A01' | 'SIU^S12' | 'ORM^O01';
}): string {
  const { patient, provider, appointment, messageType = 'SIU^S12' } = params;
  const now = new Date();
  const hl7Timestamp = now.toISOString().replace(/[-:T]/g, '').slice(0, 14);

  // MSH - Message Header
  const msh = `MSH|^~\\&|AEGIS_TELEHEALTH|HOSPITAL_SYS|EPIC_EHR|REGIONAL_CTR|${hl7Timestamp}||${messageType}|MSG${Date.now()}|P|2.5.1|||AL|NE`;

  // PID - Patient Identification
  // PID-3: Patient Identifier List (MRN)
  // PID-5: Patient Name (Family^Given)
  // PID-7: Date/Time of Birth
  // PID-8: Sex
  // PID-11: Patient Address
  // PID-13: Phone Number
  const dobHl7 = patient.dob.replace(/-/g, '');
  const pid = `PID|1||${patient.mrn}^^^AEGIS&2.16.840.1.113883.4.3.99&ISO^MR||${patient.lastName}^${patient.firstName}^^^||${dobHl7}|${patient.gender === 'female' ? 'F' : patient.gender === 'male' ? 'M' : 'U'}|||${patient.address}^^Metropolis^NY^10001^USA||${patient.phone}^PRN^PH`;

  // PV1 - Patient Visit
  // PV1-2: Patient Class (V = Virtual Telehealth, O = Outpatient)
  // PV1-3: Assigned Patient Location (TELEHEALTH^ROOM_01)
  // PV1-7: Attending Doctor (NPI^LastName^FirstName)
  // PV1-19: Visit Number
  const pv1 = `PV1|1|V|TELEHEALTH^VIRTUAL_SUITE_A^^AEGIS||||${provider.npi}^${provider.name.split(' ').pop()}^${provider.name.split(' ')[1] || ''}^^^MD|||||||||||VISIT_${appointment?.id || '99214'}|||||||||||||||||||||||||${hl7Timestamp}`;

  // OBX - Observation / Results for Vitals
  const v = patient.vitals;
  const obx1 = `OBX|1|NM|8867-4^Heart rate^LN||${v.heartRate}|/min|60-100|N|||F|||${hl7Timestamp}`;
  const obx2 = `OBX|2|ST|85354-9^Blood Pressure^LN||${v.bloodPressureSys}/${v.bloodPressureDia}|mm[Hg]|90-120/60-80|${v.bloodPressureSys > 130 ? 'H' : 'N'}|||F|||${hl7Timestamp}`;
  const obx3 = `OBX|3|NM|2708-6^Oxygen saturation^LN||${v.oxygenSaturation}|%|95-100|N|||F|||${hl7Timestamp}`;

  // DG1 - Diagnosis (from first active condition)
  const primaryCondition = patient.conditions[0];
  const dg1 = primaryCondition
    ? `DG1|1|I10|${primaryCondition.code}^${primaryCondition.name}^ICD10||${hl7Timestamp}|A`
    : `DG1|1|I10|Z00.00^General adult medical exam^ICD10||${hl7Timestamp}|A`;

  return [msh, pid, pv1, obx1, obx2, obx3, dg1].join('\r\n');
}

/**
 * Parse an HL7 v2 pipe-delimited message string into structured segments
 */
export function parseHL7Message(rawHL7: string) {
  const lines = rawHL7.trim().split(/\r\n|\r|\n/);
  const segments = lines.map(line => {
    const fields = line.split('|');
    const segmentName = fields[0];
    return {
      segment: segmentName,
      raw: line,
      fields: fields.slice(1),
    };
  });

  return {
    segmentCount: segments.length,
    messageType: segments.find(s => s.segment === 'MSH')?.fields[7] || 'UNKNOWN',
    patientMrn: segments.find(s => s.segment === 'PID')?.fields[2]?.split('^')[0] || 'N/A',
    patientName: segments.find(s => s.segment === 'PID')?.fields[4]?.replace(/\^/g, ' ') || 'N/A',
    doctorNpi: segments.find(s => s.segment === 'PV1')?.fields[6]?.split('^')[0] || 'N/A',
    segments,
  };
}
