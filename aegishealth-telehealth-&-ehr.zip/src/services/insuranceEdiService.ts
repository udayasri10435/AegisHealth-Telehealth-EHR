/**
 * ANSI ASC X12 EDI 270/271 Real-Time Eligibility & Benefit Service
 * Implements HIPAA transaction standards for real-time insurance verification:
 * - EDI 270: Health Care Eligibility Benefit Inquiry
 * - EDI 271: Health Care Eligibility Benefit Information Response
 */

import { InsurancePolicy, PatientRecord } from '../types/telehealth';

export interface EdiVerificationResult {
  transactionControlNumber: string;
  payerName: string;
  payerId: string;
  subscriberId: string;
  coverageStatus: 'ACTIVE' | 'INACTIVE' | 'REQUIRES_PRIOR_AUTH';
  planDescription: string;
  effectiveDate: string;
  coPayTelehealth: number;
  coPaySpecialist: number;
  coInsurancePercent: number;
  deductibleRemaining: number;
  outOfPocketRemaining: number;
  rawEdi270: string;
  rawEdi271: string;
  verificationTimestamp: string;
  isEligible: boolean;
  notes: string;
}

/**
 * Builds standard ANSI ASC X12 270 EDI payload string
 */
export function buildEdi270Payload(patient: PatientRecord, policy: InsurancePolicy): string {
  const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const timeStr = new Date().toTimeString().slice(0, 5).replace(/:/g, '');
  const tcn = `TCN${Math.floor(100000000 + Math.random() * 900000000)}`;

  const segments = [
    `ISA*00*          *00*          *ZZ*AEGISHEALTH    *ZZ*${policy.payerId.padEnd(15, ' ')}*${dateStr.slice(2)}*${timeStr}*^*00501*${tcn.slice(3)}*0*P*:~`,
    `GS*HS*AEGISHEALTH*${policy.payerId}*${dateStr}*${timeStr}*1*X*005010X279A1~`,
    `ST*270*0001*005010X279A1~`,
    `BHT*0022*13*${tcn}*${dateStr}*${timeStr}~`,
    `HL*1**20*1~`, // Information Source (Payer)
    `NM1*PR*2*${policy.payerName}*****PI*${policy.payerId}~`,
    `HL*2*1*21*1~`, // Information Receiver (Provider)
    `NM1*1P*1*CHEN*SARAH***MD*XX*1922039485~`,
    `HL*3*2*22*0~`, // Subscriber (Patient)
    `NM1*IL*1*${patient.lastName.toUpperCase()}*${patient.firstName.toUpperCase()}****MI*${policy.policyNumber}~`,
    `DMG*D8*${patient.dob.replace(/-/g, '')}*${patient.gender === 'female' ? 'F' : 'M'}~`,
    `DTP*291*D8*${dateStr}~`,
    `EQ*30~`, // Service Type Code 30 = Health Benefit Plan Coverage / Telemedicine
    `SE*13*0001~`,
    `GE*1*1~`,
    `IEA*1*${tcn.slice(3)}~`,
  ];

  return segments.join('\n');
}

/**
 * Simulates real-time 270 clearinghouse submission and returns parsed 271 benefit breakdown
 */
export async function verifyInsuranceEligibility(
  patient: PatientRecord,
  policy: InsurancePolicy
): Promise<EdiVerificationResult> {
  // Simulate network round-trip to Clearinghouse (e.g. Change Healthcare / Availity)
  await new Promise(resolve => setTimeout(resolve, 850));

  const tcn = `TCN${Math.floor(100000000 + Math.random() * 900000000)}`;
  const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const timeStr = new Date().toTimeString().slice(0, 5).replace(/:/g, '');

  const raw270 = buildEdi270Payload(patient, policy);

  // Compute realistic deductible and remaining
  const deductibleRemaining = Math.max(0, policy.deductibleAnnual - policy.deductibleMet);
  const outOfPocketRemaining = Math.max(0, policy.outOfPocketMax - policy.outOfPocketCurrent);

  // Build ANSI ASC X12 271 response payload
  const raw271 = [
    `ISA*00*          *00*          *ZZ*${policy.payerId.padEnd(15, ' ')}*ZZ*AEGISHEALTH    *${dateStr.slice(2)}*${timeStr}*^*00501*${tcn.slice(3)}*0*P*:~`,
    `GS*HB*${policy.payerId}*AEGISHEALTH*${dateStr}*${timeStr}*1*X*005010X279A1~`,
    `ST*271*0001*005010X279A1~`,
    `BHT*0022*11*${tcn}*${dateStr}*${timeStr}~`,
    `HL*1**20*1~`,
    `NM1*PR*2*${policy.payerName}*****PI*${policy.payerId}~`,
    `HL*2*1*21*1~`,
    `NM1*1P*1*CHEN*SARAH***MD*XX*1922039485~`,
    `HL*3*2*22*0~`,
    `NM1*IL*1*${patient.lastName.toUpperCase()}*${patient.firstName.toUpperCase()}****MI*${policy.policyNumber}~`,
    `REF*6P*${policy.groupNumber}~`,
    `EB*1**30*PR*${policy.planType}*27*${policy.copayTelehealth}*****Y~`, // Active Telehealth Copay
    `EB*C**30***23*${deductibleRemaining}*****Y~`, // Deductible remaining
    `EB*G**30***29*${outOfPocketRemaining}*****Y~`, // Out of Pocket Max remaining
    `SE*14*0001~`,
    `GE*1*1~`,
    `IEA*1*${tcn.slice(3)}~`,
  ].join('\n');

  return {
    transactionControlNumber: tcn,
    payerName: policy.payerName,
    payerId: policy.payerId,
    subscriberId: policy.policyNumber,
    coverageStatus: policy.status === 'active' ? 'ACTIVE' : 'INACTIVE',
    planDescription: `${policy.planType} - Comprehensive Medical & Telehealth Tier 1`,
    effectiveDate: policy.effectiveDate,
    coPayTelehealth: policy.copayTelehealth,
    coPaySpecialist: policy.copaySpecialist,
    coInsurancePercent: 15,
    deductibleRemaining,
    outOfPocketRemaining,
    rawEdi270: raw270,
    rawEdi271: raw271,
    verificationTimestamp: new Date().toISOString(),
    isEligible: policy.status === 'active',
    notes: policy.priorAuthRequired 
      ? 'Prior Authorization is required for specialized telehealth cardiology encounters.'
      : 'Telehealth visit covered at 100% after stated $20.00 copay. In-network benefits apply.',
  };
}
