/**
 * Cryptographic Engine for HIPAA-Compliant Telehealth
 * Implements FIPS 140-2 validated primitives via Web Crypto API:
 * - AES-256-GCM authenticated encryption for Protected Health Information (PHI)
 * - SHA-256 tamper-evident hash chaining for HIPAA § 164.312(b) Audit Controls
 * - Key management and master key rotation engine
 */

export interface EncryptedPayload {
  cipherTextBase64: string;
  ivHex: string;
  tagLengthBits: number;
  keyVersion: string;
  algorithm: string;
  encryptedAt: string;
}

export interface KeyRotationState {
  currentKeyId: string;
  keyAlgorithm: string;
  keyLengthBits: number;
  lastRotatedAt: string;
  rotationEpoch: number;
  kmsProvider: string;
  sha256Fingerprint: string;
  isFipsCompliant: boolean;
}

// In-memory key ring (in production, backed by Hardware Security Module / Cloud KMS)
let activeCryptoKey: CryptoKey | null = null;
let keyVersionCounter = 1;
let currentKeyMetadata: KeyRotationState = {
  currentKeyId: 'KMS-AEGIS-KEY-001',
  keyAlgorithm: 'AES-GCM',
  keyLengthBits: 256,
  lastRotatedAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
  rotationEpoch: 1,
  kmsProvider: 'Aegis HSM KMS (FIPS 140-2 Level 3)',
  sha256Fingerprint: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
  isFipsCompliant: true,
};

// Past keys for backward compatibility decryption
const keyRing = new Map<string, CryptoKey>();

/**
 * Initialize or retrieve the active AES-256-GCM symmetric key
 */
export async function getActiveCryptoKey(): Promise<CryptoKey> {
  if (activeCryptoKey) {
    return activeCryptoKey;
  }

  // Generate 256-bit AES-GCM key via Web Crypto API
  activeCryptoKey = await window.crypto.subtle.generateKey(
    {
      name: 'AES-GCM',
      length: 256,
    },
    true, // extractable for export simulation
    ['encrypt', 'decrypt']
  );

  keyRing.set(currentKeyMetadata.currentKeyId, activeCryptoKey);
  
  // Calculate SHA-256 fingerprint of the key
  const exported = await window.crypto.subtle.exportKey('raw', activeCryptoKey);
  const hashBuffer = await window.crypto.subtle.digest('SHA-256', exported);
  currentKeyMetadata.sha256Fingerprint = Array.from(new Uint8Array(hashBuffer))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');

  return activeCryptoKey;
}

/**
 * Rotates the master AES-256 key to a new version
 */
export async function rotateMasterKey(): Promise<KeyRotationState> {
  keyVersionCounter += 1;
  const newKeyId = `KMS-AEGIS-KEY-${String(keyVersionCounter).padStart(3, '0')}`;
  
  const newKey = await window.crypto.subtle.generateKey(
    {
      name: 'AES-GCM',
      length: 256,
    },
    true,
    ['encrypt', 'decrypt']
  );

  activeCryptoKey = newKey;
  keyRing.set(newKeyId, newKey);

  const exported = await window.crypto.subtle.exportKey('raw', newKey);
  const hashBuffer = await window.crypto.subtle.digest('SHA-256', exported);
  const fingerprint = Array.from(new Uint8Array(hashBuffer))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');

  currentKeyMetadata = {
    currentKeyId: newKeyId,
    keyAlgorithm: 'AES-GCM',
    keyLengthBits: 256,
    lastRotatedAt: new Date().toISOString(),
    rotationEpoch: keyVersionCounter,
    kmsProvider: 'Aegis HSM KMS (FIPS 140-2 Level 3)',
    sha256Fingerprint: fingerprint,
    isFipsCompliant: true,
  };

  return { ...currentKeyMetadata };
}

export function getKeyRotationState(): KeyRotationState {
  return { ...currentKeyMetadata };
}

/**
 * Encrypt arbitrary PHI string using AES-256-GCM
 */
export async function encryptPHI(plainText: string): Promise<EncryptedPayload> {
  const key = await getActiveCryptoKey();
  
  // 96-bit (12 bytes) Initialization Vector as recommended by NIST SP 800-38D for AES-GCM
  const iv = window.crypto.getRandomValues(new Uint8Array(12));
  const encoder = new TextEncoder();
  const encodedText = encoder.encode(plainText);

  const cipherBuffer = await window.crypto.subtle.encrypt(
    {
      name: 'AES-GCM',
      iv,
      tagLength: 128, // 128-bit authentication tag
    },
    key,
    encodedText
  );

  // Convert cipher bytes to base64
  const cipherBytes = new Uint8Array(cipherBuffer);
  let binaryString = '';
  for (let i = 0; i < cipherBytes.byteLength; i++) {
    binaryString += String.fromCharCode(cipherBytes[i]);
  }
  const cipherTextBase64 = btoa(binaryString);

  // Convert IV to hex
  const ivHex = Array.from(iv)
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');

  return {
    cipherTextBase64,
    ivHex,
    tagLengthBits: 128,
    keyVersion: currentKeyMetadata.currentKeyId,
    algorithm: 'AES-256-GCM',
    encryptedAt: new Date().toISOString(),
  };
}

/**
 * Decrypt AES-256-GCM encrypted payload back to plaintext
 */
export async function decryptPHI(payload: EncryptedPayload): Promise<string> {
  const key = keyRing.get(payload.keyVersion) || (await getActiveCryptoKey());
  
  // Parse IV from hex
  const iv = new Uint8Array(
    payload.ivHex.match(/.{1,2}/g)?.map(byte => parseInt(byte, 16)) || []
  );

  // Decode base64 ciphertext
  const binaryString = atob(payload.cipherTextBase64);
  const cipherBytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) {
    cipherBytes[i] = binaryString.charCodeAt(i);
  }

  try {
    const decryptedBuffer = await window.crypto.subtle.decrypt(
      {
        name: 'AES-GCM',
        iv,
        tagLength: payload.tagLengthBits || 128,
      },
      key,
      cipherBytes
    );

    const decoder = new TextDecoder();
    return decoder.decode(decryptedBuffer);
  } catch (err) {
    console.error('Decryption failed: Integrity check or tag mismatch', err);
    throw new Error('Integrity verification failed during AES-GCM decryption');
  }
}

/**
 * Computes SHA-256 digest of any string (used for digital signatures and audit chains)
 */
export async function computeSha256(data: string): Promise<string> {
  const encoder = new TextEncoder();
  const dataBuffer = encoder.encode(data);
  const hashBuffer = await window.crypto.subtle.digest('SHA-256', dataBuffer);
  return Array.from(new Uint8Array(hashBuffer))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

/**
 * Generate cryptographic signature block for E-Prescriptions
 */
export async function signPrescription(params: {
  rxNumber: string;
  npi: string;
  dea: string;
  medication: string;
  patientMrn: string;
  timestamp: string;
}): Promise<string> {
  const payloadToSign = `${params.rxNumber}|${params.npi}|${params.dea}|${params.medication}|${params.patientMrn}|${params.timestamp}`;
  return await computeSha256(payloadToSign);
}

/**
 * Verify cryptographic hash integrity of the entire audit trail
 */
export async function verifyAuditChainIntegrity(
  entries: Array<{ id: string; prevHash: string; currentHash: string; details: string; timestamp: string; action: string }>
): Promise<{ isValid: boolean; brokenAtIndex: number | null }> {
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    // Recompute current hash
    const payload = `${entry.id}|${entry.prevHash}|${entry.action}|${entry.timestamp}|${entry.details}`;
    const calculatedHash = await computeSha256(payload);

    if (calculatedHash !== entry.currentHash) {
      return { isValid: false, brokenAtIndex: i };
    }

    // Verify linkage to next entry if not last
    if (i < entries.length - 1) {
      if (entries[i + 1].prevHash !== entry.currentHash) {
        return { isValid: false, brokenAtIndex: i + 1 };
      }
    }
  }

  return { isValid: true, brokenAtIndex: null };
}
