/**
 * AegisHealth Top Navigation Bar
 * Complies with 3-zone Top Bar Contract:
 * Zone 1: Single text element wordmark with security indicator
 * Zone 2: Clean text navigation links
 * Zone 3: RBAC Role Switcher & Emergency Actions
 */

import React, { useState } from 'react';
import { 
  ShieldCheck, 
  KeyRound, 
  AlertTriangle, 
  Lock, 
  User, 
  CheckCircle2 
} from 'lucide-react';
import { UserRole, UserSession } from '../types/telehealth';

interface NavigationProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  currentSession: UserSession;
  onSwitchRole: (role: UserRole) => void;
  onOpenBreakGlass: () => void;
  onOpenKeyRotation: () => void;
  isFipsActive: boolean;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  setActiveTab,
  currentSession,
  onSwitchRole,
  onOpenBreakGlass,
  onOpenKeyRotation,
  isFipsActive,
}) => {
  const [roleDropdownOpen, setRoleDropdownOpen] = useState(false);

  const navLinks = [
    { id: 'video', label: 'Video Consult' },
    { id: 'eprescribe', label: 'E-Prescribe' },
    { id: 'ehr', label: 'EHR & FHIR' },
    { id: 'scheduling', label: 'Scheduling' },
    { id: 'insurance', label: 'Insurance EDI' },
    { id: 'baa', label: 'BAA Compliance' },
    { id: 'audit', label: 'Audit Trail' },
  ];

  const roles: { role: UserRole; title: string; badge: string }[] = [
    { role: 'physician', title: 'Physician / Provider', badge: 'MD / Clinical' },
    { role: 'patient', title: 'Patient Portal', badge: 'Self-Care' },
    { role: 'admin', title: 'Clinic Operations', badge: 'Billing / Admin' },
    { role: 'compliance_officer', title: 'Compliance Officer', badge: 'HIPAA & Legal' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Zone 1: Single Brand Wordmark */}
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setActiveTab('video')} 
              className="flex items-center gap-2.5 text-left focus:outline-hidden"
            >
              <div className="w-8 h-8 rounded-lg bg-slate-900 text-white flex items-center justify-center font-bold text-sm tracking-wider shadow-xs">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
              </div>
              <div>
                <span className="text-lg font-bold tracking-tight text-slate-900 font-sans">
                  AegisHealth
                </span>
                <div className="flex items-center gap-1.5 text-[11px] text-slate-500 font-medium">
                  <span>HIPAA Certified</span>
                  <span aria-hidden="true">·</span>
                  <span>256-Bit E2EE</span>
                </div>
              </div>
            </button>
          </div>

          {/* Zone 2: Clean Text Navigation Links */}
          <nav className="hidden lg:flex items-center space-x-1">
            {navLinks.map(link => {
              const isActive = activeTab === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => setActiveTab(link.id)}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                    isActive
                      ? 'bg-slate-100 text-slate-900 shadow-2xs font-bold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  {link.label}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Actions & Role Context */}
          <div className="flex items-center gap-2">
            
            {/* Encryption & KMS Status Button */}
            <button
              onClick={onOpenKeyRotation}
              title="Click to view AES-256 Key status & FIPS 140-2 HSM controls"
              className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 text-[11px] font-mono rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200/60 hover:bg-emerald-100 transition-colors"
            >
              <Lock className="w-3.5 h-3.5 text-emerald-600" />
              <span>AES-256-GCM</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            </button>

            {/* Emergency Break-Glass Access Button */}
            <button
              onClick={onOpenBreakGlass}
              title="Emergency Break-Glass Protocol (§ 164.312(a)(2)(ii))"
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-rose-700 bg-rose-50 border border-rose-200 rounded-md hover:bg-rose-100 transition-colors whitespace-nowrap"
            >
              <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
              <span className="hidden md:inline">Break-Glass</span>
            </button>

            {/* Role Switcher Dropdown */}
            <div className="relative">
              <button
                onClick={() => setRoleDropdownOpen(!roleDropdownOpen)}
                className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:border-slate-400 hover:bg-slate-50 focus:outline-hidden transition-all shadow-2xs"
              >
                <div className="w-5 h-5 rounded-full bg-slate-900 text-white flex items-center justify-center text-[10px] font-bold">
                  {currentSession.name.charAt(0)}
                </div>
                <div className="text-left hidden sm:block">
                  <div className="text-[11px] font-semibold text-slate-900 leading-tight">
                    {currentSession.name}
                  </div>
                  <div className="text-[10px] text-slate-500 uppercase tracking-wider font-mono">
                    {currentSession.role.replace('_', ' ')}
                  </div>
                </div>
              </button>

              {roleDropdownOpen && (
                <div 
                  className="absolute right-0 mt-2 w-64 bg-white rounded-lg border border-slate-200 shadow-xl py-1 z-50 animate-in fade-in slide-in-from-top-1"
                  onMouseLeave={() => setRoleDropdownOpen(false)}
                >
                  <div className="px-3 py-2 border-b border-slate-100">
                    <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                      Switch Role (RBAC Simulation)
                    </p>
                    <p className="text-xs text-slate-600 mt-0.5">
                      Experience AegisHealth through any persona
                    </p>
                  </div>
                  {roles.map(r => (
                    <button
                      key={r.role}
                      onClick={() => {
                        onSwitchRole(r.role);
                        setRoleDropdownOpen(false);
                      }}
                      className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between hover:bg-slate-50 transition-colors ${
                        currentSession.role === r.role ? 'bg-slate-100/80 font-semibold text-slate-900' : 'text-slate-700'
                      }`}
                    >
                      <div>
                        <div>{r.title}</div>
                        <div className="text-[10px] text-slate-500 font-normal">{r.badge}</div>
                      </div>
                      {currentSession.role === r.role && (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      )}
                    </button>
                  ))}
                </div>
              )}
            </div>

          </div>

        </div>

        {/* Mobile Navigation bar */}
        <div className="lg:hidden flex items-center gap-1 overflow-x-auto py-2 border-t border-slate-100 scrollbar-none">
          {navLinks.map(link => {
            const isActive = activeTab === link.id;
            return (
              <button
                key={link.id}
                onClick={() => setActiveTab(link.id)}
                className={`px-2.5 py-1 text-xs font-semibold rounded-md whitespace-nowrap transition-colors ${
                  isActive
                    ? 'bg-slate-900 text-white'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                {link.label}
              </button>
            );
          })}
        </div>

      </div>
    </header>
  );
};
