/**
 * HIPAA § 164.312(b) Immutable Audit Controls Engine
 * Features:
 * - Tamper-evident audit trail with SHA-256 cryptographic hash chaining
 * - Live chain integrity verification tool (detects any altered or inserted log entry)
 * - Multi-criteria search and action filtering (PHI_READ, E_PRESCRIBE, BREAK_GLASS)
 * - Compliance export to CSV / JSON for HHS Office for Civil Rights (OCR) audits
 */

import React, { useState } from 'react';
import {
  ShieldAlert,
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Download,
  Hash,
  RefreshCw,
  Lock,
  Clock,
  Eye,
  FileSpreadsheet,
} from 'lucide-react';
import { AuditLogEntry, UserSession, AuditAction } from '../types/telehealth';
import { verifyAuditChainIntegrity } from '../services/cryptoService';

interface AuditLogViewerProps {
  currentSession: UserSession;
  auditLogs: AuditLogEntry[];
}

export const AuditLogViewer: React.FC<AuditLogViewerProps> = ({
  currentSession,
  auditLogs,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [actionFilter, setActionFilter] = useState<string>('all');
  const [isVerifyingChain, setIsVerifyingChain] = useState(false);
  const [chainIntegrityStatus, setChainIntegrityStatus] = useState<{
    verified: boolean;
    valid: boolean;
    brokenIndex: number | null;
  } | null>(null);

  const handleVerifyChain = async () => {
    setIsVerifyingChain(true);
    // Sort oldest first for chain verification
    const sorted = [...auditLogs].sort(
      (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    );

    const result = await verifyAuditChainIntegrity(sorted);
    setTimeout(() => {
      setChainIntegrityStatus({
        verified: true,
        valid: result.isValid,
        brokenIndex: result.brokenAtIndex,
      });
      setIsVerifyingChain(false);
    }, 500);
  };

  const handleExportCsv = () => {
    const headers = [
      'Timestamp (UTC)',
      'Event ID',
      'Action Type',
      'User ID',
      'Role',
      'Resource',
      'Patient MRN',
      'Details',
      'IP Address',
      'SHA-256 Hash',
    ];

    const rows = auditLogs.map(log => [
      `"${log.timestamp}"`,
      `"${log.id}"`,
      `"${log.action}"`,
      `"${log.userId}"`,
      `"${log.userRole}"`,
      `"${log.resourceType}"`,
      `"${log.patientMrn || 'N/A'}"`,
      `"${log.details.replace(/"/g, '""')}"`,
      `"${log.ipAddress}"`,
      `"${log.currentHash}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `HIPAA_Audit_Trail_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    link.remove();
  };

  const handleExportJson = () => {
    const jsonString = `data:text/json;charset=utf-8,${encodeURIComponent(JSON.stringify(auditLogs, null, 2))}`;
    const link = document.createElement('a');
    link.setAttribute('href', jsonString);
    link.setAttribute('download', `HIPAA_Audit_Trail_${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(link);
    link.click();
    link.remove();
  };

  const filteredLogs = auditLogs.filter(log => {
    const matchesAction = actionFilter === 'all' || log.action === actionFilter;
    const matchesSearch =
      log.details.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (log.patientMrn && log.patientMrn.toLowerCase().includes(searchTerm.toLowerCase())) ||
      log.currentHash.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesAction && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Top Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight text-slate-900">
                HIPAA § 164.312(b) Immutable Audit Trail
              </h1>
              <span className="flex items-center gap-1 text-[11px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                <Lock className="w-3.5 h-3.5" />
                SHA-256 HASH CHAIN ACTIVE
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Tamper-evident chronological record of all PHI reads, updates, e-prescribing, video consults, and emergency break-glass operations.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleVerifyChain}
              disabled={isVerifyingChain}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-lg hover:bg-emerald-100 transition-colors"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isVerifyingChain ? 'animate-spin' : ''}`} />
              <span>Verify Cryptographic Integrity</span>
            </button>

            <button
              onClick={handleExportCsv}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>

            <button
              onClick={handleExportJson}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export JSON</span>
            </button>
          </div>
        </div>

        {/* Chain Integrity Alert Banner */}
        {chainIntegrityStatus && (
          <div className={`mt-4 p-3 rounded-lg border text-xs flex items-center justify-between ${
            chainIntegrityStatus.valid
              ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
              : 'bg-rose-50 border-rose-200 text-rose-900'
          }`}>
            <div className="flex items-center gap-2">
              {chainIntegrityStatus.valid ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              )}
              <span>
                {chainIntegrityStatus.valid
                  ? `Cryptographic Audit Chain Verified: All ${auditLogs.length} entries match forward SHA-256 linkage with 0% alteration detected.`
                  : `Integrity Alert: Chain mismatch detected at entry #${chainIntegrityStatus.brokenIndex}. Possible tampering.`}
              </span>
            </div>
            <span className="text-[10px] font-mono uppercase bg-white/80 px-2 py-0.5 rounded">
              Status: Validated
            </span>
          </div>
        )}
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-80">
          <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search details, MRN, hash..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg border border-slate-200 focus:outline-hidden focus:border-slate-900 font-sans"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Filter className="w-3.5 h-3.5 text-slate-400" />
          <select
            value={actionFilter}
            onChange={e => setActionFilter(e.target.value)}
            className="text-xs px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white w-full sm:w-auto font-medium text-slate-700"
          >
            <option value="all">All Action Types ({auditLogs.length})</option>
            <option value="PHI_READ">PHI_READ</option>
            <option value="PHI_WRITE">PHI_WRITE</option>
            <option value="E_PRESCRIBE_SIGN">E_PRESCRIBE_SIGN</option>
            <option value="CONSULT_START">CONSULT_START</option>
            <option value="CONSULT_END">CONSULT_END</option>
            <option value="INSURANCE_270_QUERY">INSURANCE_270_QUERY</option>
            <option value="FHIR_EXPORT">FHIR_EXPORT</option>
            <option value="HL7_TRANSMIT">HL7_TRANSMIT</option>
            <option value="BAA_SIGNED">BAA_SIGNED</option>
            <option value="BREAK_GLASS_ACCESS">BREAK_GLASS_ACCESS</option>
          </select>
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[10px]">
                <th className="py-3 px-4">Timestamp (UTC)</th>
                <th className="py-3 px-4">Action</th>
                <th className="py-3 px-4">User &amp; Role</th>
                <th className="py-3 px-4">Patient MRN</th>
                <th className="py-3 px-4">Audit Details</th>
                <th className="py-3 px-4">SHA-256 Tamper Seal</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              {filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center py-10 text-slate-400 font-sans text-xs">
                    No audit records match the current filter.
                  </td>
                </tr>
              ) : (
                filteredLogs.map(log => {
                  const isBreakGlass = log.action === 'BREAK_GLASS_ACCESS';
                  const isEprescribe = log.action === 'E_PRESCRIBE_SIGN';

                  return (
                    <tr
                      key={log.id}
                      className={`hover:bg-slate-50/80 transition-colors ${
                        isBreakGlass ? 'bg-rose-50/50' : ''
                      }`}
                    >
                      <td className="py-3 px-4 text-slate-500 whitespace-nowrap text-[11px] tabular-nums">
                        {log.timestamp.replace('T', ' ').slice(0, 19)}
                      </td>

                      <td className="py-3 px-4 whitespace-nowrap">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            isBreakGlass
                              ? 'bg-rose-100 text-rose-800 border border-rose-300 animate-pulse'
                              : isEprescribe
                              ? 'bg-emerald-100 text-emerald-800'
                              : log.action.includes('READ')
                              ? 'bg-sky-50 text-sky-700'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {log.action}
                        </span>
                      </td>

                      <td className="py-3 px-4 whitespace-nowrap font-sans">
                        <div className="font-semibold text-slate-800 text-xs">{log.userId}</div>
                        <div className="text-[10px] text-slate-400 uppercase font-mono">{log.userRole}</div>
                      </td>

                      <td className="py-3 px-4 whitespace-nowrap text-slate-700 text-xs font-semibold">
                        {log.patientMrn || 'N/A'}
                      </td>

                      <td className="py-3 px-4 font-sans text-slate-700 max-w-md text-xs leading-relaxed">
                        {log.details}
                      </td>

                      <td className="py-3 px-4 whitespace-nowrap text-[10px] text-slate-400">
                        <div className="flex items-center gap-1">
                          <Lock className="w-3 h-3 text-emerald-600" />
                          <span title={`Full: ${log.currentHash}`}>
                            {log.currentHash.slice(0, 12)}...{log.currentHash.slice(-6)}
                          </span>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
