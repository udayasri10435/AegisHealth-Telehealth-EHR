/**
 * HIPAA-Compliant Scheduling & Clinical Intake Triage
 * Features:
 * - Multi-Provider Availability & Slot Reservation
 * - Interactive Patient Intake Wizard with Clinical Triage Severity Scoring
 * - Mandatory HIPAA Notice of Privacy Practices (NPP) Consent Enforcement
 * - Real-time Waiting Room Status & Telehealth Launchpad
 */

import React, { useState } from 'react';
import {
  Calendar as CalendarIcon,
  Clock,
  User,
  AlertCircle,
  CheckCircle2,
  Video,
  Plus,
  ShieldCheck,
  Stethoscope,
  ChevronRight,
  Filter,
} from 'lucide-react';
import {
  PatientRecord,
  ProviderRecord,
  AppointmentRecord,
  UserSession,
} from '../types/telehealth';

interface SchedulingManagerProps {
  currentSession: UserSession;
  patients: PatientRecord[];
  providers: ProviderRecord[];
  appointments: AppointmentRecord[];
  onAddAppointment: (newAppt: AppointmentRecord) => void;
  onJoinConsult: (appt: AppointmentRecord) => void;
  onLogAuditEvent: (action: any, details: string) => void;
}

export const SchedulingManager: React.FC<SchedulingManagerProps> = ({
  currentSession,
  patients,
  providers,
  appointments,
  onAddAppointment,
  onJoinConsult,
  onLogAuditEvent,
}) => {
  const [selectedProviderFilter, setSelectedProviderFilter] = useState<string>('all');
  const [isBookingOpen, setIsBookingOpen] = useState(false);

  // Intake Booking Form State
  const [bookingPatientId, setBookingPatientId] = useState(patients[0].id);
  const [bookingProviderId, setBookingProviderId] = useState(providers[0].id);
  const [bookingDate, setBookingDate] = useState('2026-09-30');
  const [bookingTime, setBookingTime] = useState('14:30');
  const [chiefComplaint, setChiefComplaint] = useState('');
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [hipaaConsentSigned, setHipaaConsentSigned] = useState(false);
  const [triageUrgency, setTriageUrgency] = useState<'routine' | 'moderate' | 'urgent'>('routine');

  const SYMPTOM_CHECKLIST = [
    { label: 'Chest Pressure or Palpitations', severity: 'urgent' },
    { label: 'Shortness of Breath on Exertion', severity: 'urgent' },
    { label: 'Blood Pressure > 140/90 at Home', severity: 'moderate' },
    { label: 'Medication Refill Request', severity: 'routine' },
    { label: 'Chronic Disease Routine Check-up', severity: 'routine' },
    { label: 'Seasonal Allergy Flare-up', severity: 'moderate' },
    { label: 'Dizziness or Occasional Headaches', severity: 'moderate' },
  ];

  const handleToggleSymptom = (label: string, severity: string) => {
    let next: string[];
    if (selectedSymptoms.includes(label)) {
      next = selectedSymptoms.filter(s => s !== label);
    } else {
      next = [...selectedSymptoms, label];
    }
    setSelectedSymptoms(next);

    // Auto calculate triage score
    const hasUrgent = next.some(s => {
      const item = SYMPTOM_CHECKLIST.find(i => i.label === s);
      return item?.severity === 'urgent';
    });
    const hasModerate = next.some(s => {
      const item = SYMPTOM_CHECKLIST.find(i => i.label === s);
      return item?.severity === 'moderate';
    });

    if (hasUrgent) setTriageUrgency('urgent');
    else if (hasModerate) setTriageUrgency('moderate');
    else setTriageUrgency('routine');
  };

  const handleConfirmBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (!hipaaConsentSigned) {
      alert('HIPAA Notice of Privacy Practices consent is mandatory before booking.');
      return;
    }

    const patient = patients.find(p => p.id === bookingPatientId) || patients[0];
    const provider = providers.find(p => p.id === bookingProviderId) || providers[0];
    const newId = `apt-${Date.now()}`;
    const roomId = `room-aegis-${Math.random().toString(36).substring(2, 7)}`;

    const newAppointment: AppointmentRecord = {
      id: newId,
      patientId: patient.id,
      patientName: `${patient.firstName} ${patient.lastName}`,
      providerId: provider.id,
      providerName: provider.name,
      dateTime: `${bookingDate}T${bookingTime}:00Z`,
      durationMinutes: 30,
      status: 'scheduled',
      chiefComplaint: chiefComplaint || 'Routine Telehealth Clinical Follow-up',
      triageUrgency,
      symptoms: selectedSymptoms,
      intakeCompleted: true,
      hipaaConsentSigned: true,
      roomId,
    };

    onAddAppointment(newAppointment);
    setIsBookingOpen(false);

    // Reset fields
    setChiefComplaint('');
    setSelectedSymptoms([]);
    setHipaaConsentSigned(false);

    onLogAuditEvent(
      'PHI_WRITE',
      `New telehealth encounter booked for ${patient.firstName} ${patient.lastName} (MRN: ${patient.mrn}) with ${provider.name}. Room: ${roomId}`
    );
  };

  const filteredAppointments = appointments.filter(a => {
    if (selectedProviderFilter === 'all') return true;
    return a.providerId === selectedProviderFilter;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Top Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight text-slate-900">
                Telehealth Scheduling &amp; Clinical Triage
              </h1>
              <span className="flex items-center gap-1 text-[11px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                <CalendarIcon className="w-3.5 h-3.5" />
                ONLINE SCHEDULER
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Encrypted patient bookings with automated symptom triage, HIPAA NPP consent, and waiting room launchpad.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <Filter className="w-3.5 h-3.5 text-slate-400" />
              <select
                value={selectedProviderFilter}
                onChange={e => setSelectedProviderFilter(e.target.value)}
                className="text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
              >
                <option value="all">All Providers ({providers.length})</option>
                {providers.map(prov => (
                  <option key={prov.id} value={prov.id}>
                    {prov.name}
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={() => setIsBookingOpen(true)}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors shadow-2xs whitespace-nowrap"
            >
              <Plus className="w-4 h-4 text-emerald-400" />
              <span>Book Consultation</span>
            </button>
          </div>
        </div>
      </div>

      {/* Provider Profiles Quick Strip */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {providers.map(p => (
          <div key={p.id} className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs space-y-2">
            <div className="flex items-start justify-between">
              <div>
                <div className="font-bold text-xs text-slate-900">{p.name}</div>
                <div className="text-[11px] text-slate-500">{p.specialty}</div>
              </div>
              <span className="text-[10px] font-mono bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded">
                ${p.consultFee}/visit
              </span>
            </div>
            <div className="text-[11px] text-slate-600 flex items-center gap-2 font-mono">
              <span>NPI: {p.npi}</span>
              <span aria-hidden="true">·</span>
              <span>DEA: {p.dea}</span>
            </div>
            <div className="text-[10px] text-emerald-700 bg-emerald-50 px-2 py-1 rounded flex items-center gap-1">
              <Clock className="w-3 h-3 text-emerald-600" />
              <span>Available: {p.availableDays.join(', ')} (09:00 - 17:00 EST)</span>
            </div>
          </div>
        ))}
      </div>

      {/* Appointments List */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 bg-slate-50/60 flex items-center justify-between">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
            Upcoming Telehealth Queue ({filteredAppointments.length})
          </span>
          <span className="text-xs text-slate-400 font-mono">Real-Time WebRTC Waiting Room</span>
        </div>

        <div className="divide-y divide-slate-100">
          {filteredAppointments.length === 0 ? (
            <div className="p-12 text-center text-slate-400 text-xs">
              No appointments found for the selected filter.
            </div>
          ) : (
            filteredAppointments.map(appt => {
              const isWaiting = appt.status === 'waiting';
              const isInCall = appt.status === 'in_call';

              return (
                <div key={appt.id} className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:bg-slate-50/80 transition-colors">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-slate-900">{appt.patientName}</span>
                      <span className={`text-[10px] uppercase font-mono font-bold px-2 py-0.5 rounded-full ${
                        appt.triageUrgency === 'urgent'
                          ? 'bg-rose-100 text-rose-800'
                          : appt.triageUrgency === 'moderate'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-slate-100 text-slate-700'
                      }`}>
                        {appt.triageUrgency} triage
                      </span>

                      {isWaiting && (
                        <span className="text-[10px] font-mono text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full animate-pulse flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                          IN WAITING ROOM
                        </span>
                      )}
                    </div>

                    <div className="text-xs text-slate-600">
                      Chief Complaint: <span className="text-slate-800 font-medium">{appt.chiefComplaint}</span>
                    </div>

                    <div className="flex items-center gap-3 text-[11px] text-slate-400 font-mono">
                      <span>Provider: {appt.providerName}</span>
                      <span aria-hidden="true">·</span>
                      <span>Scheduled: {appt.dateTime.replace('T', ' ').slice(0, 16)}</span>
                      <span aria-hidden="true">·</span>
                      <span>Duration: {appt.durationMinutes} min</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onJoinConsult(appt)}
                      className={`px-4 py-2 text-xs font-semibold rounded-lg flex items-center gap-2 transition-all ${
                        isWaiting
                          ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm ring-2 ring-emerald-500/20'
                          : 'bg-slate-900 hover:bg-slate-800 text-white'
                      }`}
                    >
                      <Video className="w-4 h-4" />
                      <span>{isWaiting ? 'Admit Patient Now' : 'Join Video Consult'}</span>
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Booking Modal */}
      {isBookingOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-xl w-full max-h-[90vh] overflow-y-auto p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div>
                <h3 className="text-base font-bold text-slate-900">Schedule Telehealth Appointment</h3>
                <p className="text-xs text-slate-500">Electronic intake with clinical severity scoring</p>
              </div>
              <button onClick={() => setIsBookingOpen(false)} className="text-slate-400 hover:text-slate-600">
                ✕
              </button>
            </div>

            <form onSubmit={handleConfirmBooking} className="mt-4 space-y-4">
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Patient</label>
                  <select
                    value={bookingPatientId}
                    onChange={e => setBookingPatientId(e.target.value)}
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200 bg-white"
                  >
                    {patients.map(p => (
                      <option key={p.id} value={p.id}>
                        {p.firstName} {p.lastName} ({p.mrn})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Physician / Specialty</label>
                  <select
                    value={bookingProviderId}
                    onChange={e => setBookingProviderId(e.target.value)}
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200 bg-white"
                  >
                    {providers.map(prov => (
                      <option key={prov.id} value={prov.id}>
                        {prov.name} ({prov.specialty})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Date</label>
                  <input
                    type="date"
                    value={bookingDate}
                    onChange={e => setBookingDate(e.target.value)}
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Time Slot (EST)</label>
                  <input
                    type="time"
                    value={bookingTime}
                    onChange={e => setBookingTime(e.target.value)}
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Reason for Visit / Chief Complaint
                </label>
                <input
                  type="text"
                  placeholder="e.g. Follow-up on blood pressure and review laboratory tests"
                  value={chiefComplaint}
                  onChange={e => setChiefComplaint(e.target.value)}
                  className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:border-slate-900"
                  required
                />
              </div>

              {/* Symptom Checklist with Urgency Triage */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold text-slate-700">
                    Clinical Symptom Questionnaire
                  </label>
                  <span className={`text-[10px] uppercase font-mono font-bold px-2 py-0.5 rounded ${
                    triageUrgency === 'urgent'
                      ? 'bg-rose-100 text-rose-800'
                      : triageUrgency === 'moderate'
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-emerald-50 text-emerald-800'
                  }`}>
                    Assessed Triage: {triageUrgency}
                  </span>
                </div>
                <div className="space-y-1.5 bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                  {SYMPTOM_CHECKLIST.map((item, idx) => (
                    <label key={idx} className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={selectedSymptoms.includes(item.label)}
                        onChange={() => handleToggleSymptom(item.label, item.severity)}
                        className="rounded border-slate-300 text-slate-900 focus:ring-0"
                      />
                      <span>{item.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Mandatory HIPAA Notice of Privacy Practices check */}
              <div className="p-3 bg-emerald-50/60 border border-emerald-200 rounded-lg space-y-2">
                <div className="flex items-start gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                  <div className="text-[11px] text-slate-700 leading-relaxed">
                    <strong>HIPAA Notice of Privacy Practices Acknowledgement:</strong> I consent to telehealth evaluation via encrypted audiovisual transmission, understanding my medical records and PHI are protected under federal HIPAA Privacy & Security Rules (45 CFR Parts 160/164).
                  </div>
                </div>
                <label className="flex items-center gap-2 text-xs font-bold text-emerald-900 cursor-pointer pt-1">
                  <input
                    type="checkbox"
                    checked={hipaaConsentSigned}
                    onChange={e => setHipaaConsentSigned(e.target.checked)}
                    className="rounded border-emerald-400 text-emerald-700 focus:ring-0"
                    required
                  />
                  <span>I acknowledge and electronically execute the HIPAA consent statement.</span>
                </label>
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsBookingOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!hipaaConsentSigned}
                  className="px-4 py-2 text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white rounded-lg transition-colors disabled:opacity-50"
                >
                  Confirm &amp; Schedule
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
};
