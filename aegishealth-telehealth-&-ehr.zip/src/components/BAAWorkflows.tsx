/**
 * HIPAA Business Associate Agreement (BAA) Governance Center
 * Complies with 45 CFR § 164.502(e) and § 164.504(e) Requirements:
 * - Sub-Processor & Cloud Vendor BAA Registry
 * - Statutory Safeguard & Breach Notification Clauses (HHS OCR Mandates)
 * - Interactive Digital Signing Workflow with SHA-256 Tamper Seal
 * - Executed Agreement Viewer & Download Generator
 */

import React, { useState } from 'react';
import {
  FileCheck,
  ShieldCheck,
  Building,
  Lock,
  Clock,
  AlertTriangle,
  Download,
  PenTool,
  CheckCircle2,
  ExternalLink,
} from 'lucide-react';
import { BAARecord, UserSession } from '../types/telehealth';
import { computeSha256 } from '../services/cryptoService';

interface BAAWorkflowsProps {
  currentSession: UserSession;
  baaList: BAARecord[];
  onUpdateBaa: (updated: BAARecord) => void;
  onLogAuditEvent: (action: any, details: string) => void;
}

export const BAAWorkflows: React.FC<BAAWorkflowsProps> = ({
  currentSession,
  baaList,
  onUpdateBaa,
  onLogAuditEvent,
}) => {
  const [selectedBaa, setSelectedBaa] = useState<BAARecord>(baaList[0]);
  const [signingModalOpen, setSigningModalOpen] = useState(false);
  const [legalEntityName, setLegalEntityName] = useState('Aegis Memorial Telehealth Network, LLC');
  const [signatoryName, setSignatoryName] = useState(currentSession.name);
  const [signatoryTitle, setSignatoryTitle] = useState(currentSession.title);
  const [isSigning, setIsSigning] = useState(false);

  const handleExecuteSigning = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSigning(true);

    const now = new Date().toISOString();
    const payload = `${selectedBaa.vendorName}|${legalEntityName}|${signatoryName}|${signatoryTitle}|${now}`;
    const sha256Seal = await computeSha256(payload);

    const executedBaa: BAARecord = {
      ...selectedBaa,
      status: 'active',
      executedDate: now.slice(0, 10),
      expiryDate: new Date(Date.now() + 2 * 365 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10),
      signatoryName,
      signatoryTitle,
      sha256Seal,
    };

    setTimeout(() => {
      onUpdateBaa(executedBaa);
      setSelectedBaa(executedBaa);
      setIsSigning(false);
      setSigningModalOpen(false);

      onLogAuditEvent(
        'BAA_SIGNED',
        `Executed HIPAA Business Associate Agreement with ${executedBaa.vendorName}. Signed by ${signatoryName} (${signatoryTitle}). SHA-256: ${sha256Seal.slice(0, 16)}...`
      );
    }, 600);
  };

  const handleDownloadBaaText = () => {
    const textContent = `
BUSINESS ASSOCIATE AGREEMENT (BAA)
Governed by 45 CFR Parts 160 and 164 (HIPAA / HITECH / Omnibus Final Rule)

COVERED ENTITY: ${legalEntityName}
BUSINESS ASSOCIATE: ${selectedBaa.vendorName}
CATEGORY: ${selectedBaa.serviceCategory}
STATUS: ${selectedBaa.status.toUpperCase()}
EXECUTION DATE: ${selectedBaa.executedDate}
EXPIRATION DATE: ${selectedBaa.expiryDate}

1. RECITALS & PURPOSE
This Business Associate Agreement ("BAA") governs the creation, receipt, maintenance, transmission, and protection of Protected Health Information (PHI) and Electronic PHI (ePHI) in connection with the cloud telehealth and EHR infrastructure provided by Business Associate.

2. STATUTORY SAFEGUARDS (45 CFR § 164.504(e)(2)(ii)(B))
Business Associate warrants and certifies that it has implemented administrative, physical, and technical safeguards that reasonably and appropriately protect the confidentiality, integrity, and availability of ePHI, complying with FIPS 140-2 validated encryption (AES-256-GCM) at rest and TLS 1.3 in transit.

3. BREACH NOTIFICATION (45 CFR § 164.410)
Business Associate shall report any unauthorized acquisition, access, use, or disclosure of unencrypted PHI ("Breach") to Covered Entity without unreasonable delay and in no event later than ${selectedBaa.hhsBreachProtocolHours} hours following discovery.

4. PERMITTED SERVICES
${selectedBaa.coveredServices.map(s => `- ${s}`).join('\n')}

5. CRYPTOGRAPHIC TAMPER SEAL
SHA-256 Seal: ${selectedBaa.sha256Seal}
Electronic Attestation By: ${selectedBaa.signatoryName}, ${selectedBaa.signatoryTitle}
`.trim();

    const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `BAA_${selectedBaa.vendorName.replace(/[^a-zA-Z0-9]/g, '_')}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight text-slate-900">
                Business Associate Agreement (BAA) Governance
              </h1>
              <span className="flex items-center gap-1 text-[11px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                <ShieldCheck className="w-3.5 h-3.5" />
                45 CFR § 164.502(e) &amp; § 164.504(e)
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Statutory agreements tracking PHI safeguards, cloud infrastructure sub-processors, and 24-72h breach notification protocols.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono text-slate-500">
            <span>Total Vendors: <strong>{baaList.length}</strong></span>
            <span aria-hidden="true">·</span>
            <span className="text-emerald-700">Active BAAs: <strong>{baaList.filter(b => b.status === 'active').length}</strong></span>
          </div>
        </div>
      </div>

      {/* Main Grid: Vendor Registry & Selected BAA Details */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column: Vendor Registry (1 Col) */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs space-y-3">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Registered Sub-Processors
          </div>
          <div className="space-y-2">
            {baaList.map(baa => {
              const isSelected = baa.id === selectedBaa.id;
              const isActive = baa.status === 'active';

              return (
                <button
                  key={baa.id}
                  onClick={() => setSelectedBaa(baa)}
                  className={`w-full text-left p-3 rounded-lg border transition-all ${
                    isSelected
                      ? 'border-slate-900 bg-slate-50 shadow-2xs'
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-xs text-slate-900 truncate max-w-[190px]">
                      {baa.vendorName}
                    </span>
                    <span className={`text-[10px] font-mono uppercase px-1.5 py-0.5 rounded ${
                      isActive ? 'bg-emerald-50 text-emerald-700 font-semibold' : 'bg-amber-50 text-amber-800'
                    }`}>
                      {baa.status.replace('_', ' ')}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 truncate">{baa.serviceCategory}</div>
                  <div className="text-[10px] text-slate-400 font-mono mt-1">
                    Executed: {baa.executedDate} · Exp: {baa.expiryDate}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Columns: Active BAA Contract Inspector (2 Cols) */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-6">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
            <div>
              <div className="flex items-center gap-2">
                <Building className="w-5 h-5 text-slate-700" />
                <h3 className="text-base font-bold text-slate-900">{selectedBaa.vendorName}</h3>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">{selectedBaa.serviceCategory}</p>
            </div>

            <div className="flex items-center gap-2">
              {selectedBaa.status === 'pending_signature' ? (
                <button
                  onClick={() => setSigningModalOpen(true)}
                  className="px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors flex items-center gap-1.5 shadow-2xs"
                >
                  <PenTool className="w-3.5 h-3.5" />
                  <span>Execute Digital Signature</span>
                </button>
              ) : (
                <button
                  onClick={handleDownloadBaaText}
                  className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Executed Agreement</span>
                </button>
              )}
            </div>
          </div>

          {/* Statutory Clauses Checklist */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Mandatory Statutory Provisions (§ 164.504(e))
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                <div className="flex items-center gap-1.5 font-bold text-slate-900">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Safeguards Clause (§ 164.504(e)(2)(ii)(B))</span>
                </div>
                <p className="text-[11px] text-slate-600">
                  Requires Business Associate to employ administrative, physical, and technical controls (AES-256 / TLS 1.3) protecting ePHI.
                </p>
              </div>

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                <div className="flex items-center gap-1.5 font-bold text-slate-900">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Breach Protocol (§ 164.410)</span>
                </div>
                <p className="text-[11px] text-slate-600">
                  Contractual obligation to notify Covered Entity of any security incident within <strong>{selectedBaa.hhsBreachProtocolHours} hours</strong>.
                </p>
              </div>

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                <div className="flex items-center gap-1.5 font-bold text-slate-900">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Subcontractor Flow-Down (§ 164.502(e)(1)(ii))</span>
                </div>
                <p className="text-[11px] text-slate-600">
                  Mandates any downstream agent or sub-contractor adhere to identical PHI restrictions and safeguards.
                </p>
              </div>

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                <div className="flex items-center gap-1.5 font-bold text-slate-900">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Destruction of PHI (§ 164.504(e)(2)(ii)(I))</span>
                </div>
                <p className="text-[11px] text-slate-600">
                  Guarantees return or certified cryptographic purge of all PHI records upon termination of master service agreement.
                </p>
              </div>
            </div>
          </div>

          {/* Covered Telehealth Services */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              Permitted Services &amp; Infrastructure Scope
            </h4>
            <div className="flex flex-wrap gap-2">
              {selectedBaa.coveredServices.map((service, idx) => (
                <span
                  key={idx}
                  className="text-xs font-mono bg-slate-100 text-slate-800 px-2.5 py-1 rounded-md border border-slate-200"
                >
                  {service}
                </span>
              ))}
            </div>
          </div>

          {/* Cryptographic Execution Block */}
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2 text-xs font-mono">
            <div className="flex items-center justify-between text-slate-500 font-sans">
              <span className="font-bold text-slate-800">Legal Execution Attestation</span>
              <span>Valid Through: {selectedBaa.expiryDate}</span>
            </div>
            <div className="text-slate-700">
              Authorized Signatory: <strong className="font-sans">{selectedBaa.signatoryName}</strong> ({selectedBaa.signatoryTitle})
            </div>
            <div className="text-slate-600 break-all bg-white p-2.5 rounded border border-slate-200 text-[11px]">
              <div className="text-[10px] text-slate-400 mb-0.5">IMMUTABLE SHA-256 DIGITAL SEAL:</div>
              {selectedBaa.sha256Seal}
            </div>
          </div>

        </div>

      </div>

      {/* Electronic Execution Modal */}
      {signingModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-lg w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div>
                <h3 className="text-base font-bold text-slate-900">Execute Business Associate Agreement</h3>
                <p className="text-xs text-slate-500">Vendor: {selectedBaa.vendorName}</p>
              </div>
              <button onClick={() => setSigningModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                ✕
              </button>
            </div>

            <form onSubmit={handleExecuteSigning} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Covered Entity Legal Name</label>
                <input
                  type="text"
                  value={legalEntityName}
                  onChange={e => setLegalEntityName(e.target.value)}
                  className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Signatory Full Name</label>
                  <input
                    type="text"
                    value={signatoryName}
                    onChange={e => setSignatoryName(e.target.value)}
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Job Title / Credentials</label>
                  <input
                    type="text"
                    value={signatoryTitle}
                    onChange={e => setSignatoryTitle(e.target.value)}
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200"
                    required
                  />
                </div>
              </div>

              <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-200 text-xs text-emerald-900 space-y-1">
                <div className="font-bold flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-700" />
                  <span>ESIGN Act &amp; HIPAA Attestation</span>
                </div>
                <p className="text-[11px] leading-relaxed">
                  By clicking Execute, I certify that I am legally authorized to enter into binding HIPAA Business Associate obligations for the designated covered entity.
                </p>
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setSigningModalOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSigning}
                  className="px-4 py-2 text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg transition-colors flex items-center gap-1.5"
                >
                  {isSigning ? 'Calculating Hash Seal...' : 'Seal & Execute Agreement'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
