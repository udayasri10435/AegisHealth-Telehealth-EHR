/**
 * HIPAA § 164.312(a)(2)(ii) Emergency Access "Break-Glass" Modal
 * Mandated protocol providing critical emergency override for clinical life-safety events.
 */

import React, { useState } from 'react';
import { AlertTriangle, ShieldAlert, Lock, CheckCircle2 } from 'lucide-react';
import { PatientRecord, UserSession } from '../types/telehealth';

interface BreakGlassModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentSession: UserSession;
  patients: PatientRecord[];
  onExecuteBreakGlass: (patient: PatientRecord, reason: string, category: string) => void;
}

export const BreakGlassModal: React.FC<BreakGlassModalProps> = ({
  isOpen,
  onClose,
  currentSession,
  patients,
  onExecuteBreakGlass,
}) => {
  const [selectedPatientId, setSelectedPatientId] = useState(patients[0].id);
  const [emergencyCategory, setEmergencyCategory] = useState('life_threatening');
  const [clinicalReason, setClinicalReason] = useState('');
  const [complianceAcknowledgement, setComplianceAcknowledgement] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const selectedPatient = patients.find(p => p.id === selectedPatientId) || patients[0];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!complianceAcknowledgement) {
      alert('You must acknowledge that this emergency override will be audited by the HIPAA Privacy Officer.');
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      onExecuteBreakGlass(selectedPatient, clinicalReason, emergencyCategory);
      setIsSubmitting(false);
      onClose();
      alert(`Break-Glass emergency override granted for patient ${selectedPatient.mrn}. Compliance Officer notified.`);
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl max-w-lg w-full p-6 shadow-2xl border-2 border-rose-500 animate-in fade-in zoom-in-95">
        
        {/* Warning Header */}
        <div className="flex items-center gap-3 pb-3 border-b border-rose-100">
          <div className="w-10 h-10 rounded-full bg-rose-100 text-rose-700 flex items-center justify-center shrink-0">
            <AlertTriangle className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h3 className="text-base font-bold text-rose-900">
              HIPAA Emergency "Break-Glass" Access
            </h3>
            <p className="text-[11px] text-rose-700 font-mono">
              45 CFR § 164.312(a)(2)(ii) Emergency Access Procedure
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          
          <div className="p-3 bg-rose-50 rounded-lg text-xs text-rose-800 space-y-1">
            <strong>CRITICAL WARNING:</strong> You are invoking an emergency clinical override to access Restricted Protected Health Information (PHI) without standard patient consent. This event generates an immutable compliance alert sent directly to the HIPAA Security Officer.
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Target Patient Chart</label>
            <select
              value={selectedPatientId}
              onChange={e => setSelectedPatientId(e.target.value)}
              className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 bg-white"
            >
              {patients.map(p => (
                <option key={p.id} value={p.id}>
                  {p.firstName} {p.lastName} (MRN: {p.mrn})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Emergency Justification Category</label>
            <select
              value={emergencyCategory}
              onChange={e => setEmergencyCategory(e.target.value)}
              className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 bg-white"
            >
              <option value="life_threatening">Life-Threatening Clinical Emergency / Cardiac Arrest</option>
              <option value="unconscious_patient">Unconscious / Incapacitated Patient Without Proxy</option>
              <option value="critical_allergy_lookup">Urgent Adverse Drug Reaction / Allergy Verification</option>
              <option value="system_override">Disaster Recovery / System Authorization Bypass</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Mandatory Clinical Rationale &amp; Justification
            </label>
            <textarea
              rows={3}
              placeholder="State precise medical reason requiring emergency access to this patient's records..."
              value={clinicalReason}
              onChange={e => setClinicalReason(e.target.value)}
              className="w-full text-xs p-2.5 rounded-lg border border-slate-300 focus:outline-hidden focus:border-rose-600 resize-none"
              required
            />
          </div>

          <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
            <label className="flex items-start gap-2 text-xs text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={complianceAcknowledgement}
                onChange={e => setComplianceAcknowledgement(e.target.checked)}
                className="mt-0.5 rounded border-slate-300 text-rose-600 focus:ring-0"
                required
              />
              <span>
                I swear under penalty of federal HIPAA non-compliance penalties that this emergency access is strictly required to provide urgent medical treatment.
              </span>
            </label>
          </div>

          <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting || !complianceAcknowledgement || !clinicalReason.trim()}
              className="px-4 py-2 text-xs font-semibold bg-rose-600 hover:bg-rose-700 text-white rounded-lg transition-colors disabled:opacity-50 flex items-center gap-1.5"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>{isSubmitting ? 'Verifying Credentials...' : 'Authorize Emergency Access'}</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
