/**
 * EHR Integration Suite: FHIR R4 & HL7 v2 Interoperability Hub
 * Features:
 * - HL7 FHIR R4 Resource Explorer & Bundle Exporter (Patient, Encounter, Observation, Condition, MedicationRequest)
 * - HL7 v2.5.1 Pipe-and-Hat Message Generator & Segment Parser (MSH, PID, PV1, OBX, DG1)
 * - AES-256-GCM PHI Cryptographic Vault Inspector
 */

import React, { useState, useEffect } from 'react';
import {
  FileCode2,
  Database,
  Lock,
  Download,
  Send,
  CheckCircle2,
  Search,
  Code,
  Layers,
  ArrowRight,
  Shield,
  Key,
  RefreshCw,
  Eye,
  EyeOff,
} from 'lucide-react';
import { PatientRecord, AppointmentRecord, PrescriptionRecord, ProviderRecord } from '../types/telehealth';
import {
  generateFhirBundle,
  generateHL7Message,
  parseHL7Message,
  generateFhirPatient,
  generateFhirVitalObservations,
} from '../services/fhirHl7Service';
import { encryptPHI, decryptPHI, EncryptedPayload } from '../services/cryptoService';

interface EHRIntegrationProps {
  patients: PatientRecord[];
  providers: ProviderRecord[];
  appointments: AppointmentRecord[];
  prescriptions: PrescriptionRecord[];
  onLogAuditEvent: (action: any, details: string) => void;
}

export const EHRIntegration: React.FC<EHRIntegrationProps> = ({
  patients,
  providers,
  appointments,
  prescriptions,
  onLogAuditEvent,
}) => {
  const [selectedPatientId, setSelectedPatientId] = useState<string>(patients[0].id);
  const [activeEngineTab, setActiveEngineTab] = useState<'fhir' | 'hl7' | 'encryption'>('fhir');
  
  // FHIR states
  const [selectedFhirResource, setSelectedFhirResource] = useState<'Bundle' | 'Patient' | 'Observations'>('Bundle');
  const [isExporting, setIsExporting] = useState(false);
  const [exportSuccess, setExportSuccess] = useState(false);

  // HL7 states
  const [hl7MessageType, setHl7MessageType] = useState<'SIU^S12' | 'ADT^A01' | 'ORM^O01'>('SIU^S12');
  const [customHl7Input, setCustomHl7Input] = useState('');
  const [parsedHl7, setParsedHl7] = useState<any>(null);

  // AES-256 PHI Vault states
  const [encryptedVault, setEncryptedVault] = useState<Record<string, EncryptedPayload>>({});
  const [decryptedValues, setDecryptedValues] = useState<Record<string, string>>({});
  const [showPlaintext, setShowPlaintext] = useState(false);
  const [isEncrypting, setIsEncrypting] = useState(false);

  const currentPatient = patients.find(p => p.id === selectedPatientId) || patients[0];
  const currentProvider = providers[0];
  const currentAppointment = appointments.find(a => a.patientId === currentPatient.id);

  // Re-generate FHIR Bundle
  const fhirBundle = generateFhirBundle(currentPatient, appointments, prescriptions);
  const fhirPatient = generateFhirPatient(currentPatient);
  const fhirObservations = generateFhirVitalObservations(currentPatient);

  // Re-generate HL7 v2
  const generatedHl7 = generateHL7Message({
    patient: currentPatient,
    provider: currentProvider,
    appointment: currentAppointment,
    messageType: hl7MessageType,
  });

  // Parse HL7 on update
  useEffect(() => {
    const raw = customHl7Input || generatedHl7;
    try {
      setParsedHl7(parseHL7Message(raw));
    } catch (e) {
      setParsedHl7(null);
    }
  }, [customHl7Input, generatedHl7]);

  // Run AES-256-GCM encryption on current patient's PHI
  const runEncryptionDemo = async () => {
    setIsEncrypting(true);
    const ssnEnc = await encryptPHI(currentPatient.ssnMasked);
    const dobEnc = await encryptPHI(currentPatient.dob);
    const addrEnc = await encryptPHI(currentPatient.address);
    const diagEnc = await encryptPHI(currentPatient.conditions.map(c => `${c.code}: ${c.name}`).join('; '));

    setEncryptedVault({
      ssn: ssnEnc,
      dob: dobEnc,
      address: addrEnc,
      conditions: diagEnc,
    });
    setIsEncrypting(false);

    onLogAuditEvent(
      'PHI_READ',
      `FIPS 140-2 AES-256-GCM Cryptographic vault inspection executed for MRN ${currentPatient.mrn}`
    );
  };

  useEffect(() => {
    runEncryptionDemo();
  }, [selectedPatientId]);

  const handleTestDecryption = async (field: string) => {
    const payload = encryptedVault[field];
    if (!payload) return;
    try {
      const plaintext = await decryptPHI(payload);
      setDecryptedValues(prev => ({ ...prev, [field]: plaintext }));
    } catch (e) {
      alert('Decryption authentication tag verification failed.');
    }
  };

  const handleDownloadFhirBundle = () => {
    setIsExporting(true);
    const jsonString = `data:text/json;charset=utf-8,${encodeURIComponent(JSON.stringify(fhirBundle, null, 2))}`;
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', jsonString);
    downloadAnchor.setAttribute('download', `FHIR_R4_Bundle_${currentPatient.mrn}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();

    setIsExporting(false);
    setExportSuccess(true);
    setTimeout(() => setExportSuccess(false), 3000);

    onLogAuditEvent(
      'FHIR_EXPORT',
      `Exported compliant HL7 FHIR R4 JSON Bundle for MRN ${currentPatient.mrn} (Total resources: ${fhirBundle.total})`
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Top Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight text-slate-900">
                EHR Interoperability & Cryptographic Vault
              </h1>
              <span className="flex items-center gap-1 text-[11px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                <Database className="w-3.5 h-3.5" />
                HL7 FHIR R4 &amp; v2.5.1
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Synchronize telehealth notes, observations, and e-prescriptions with Epic, Cerner, and ONC-certified health systems.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <label className="text-xs text-slate-500 font-semibold">Active Patient:</label>
            <select
              value={selectedPatientId}
              onChange={e => setSelectedPatientId(e.target.value)}
              className="text-xs px-3 py-1.5 rounded-lg border border-slate-300 bg-white font-medium text-slate-800"
            >
              {patients.map(p => (
                <option key={p.id} value={p.id}>
                  {p.firstName} {p.lastName} ({p.mrn})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Engine Switcher Tabs */}
        <div className="flex items-center gap-2 mt-4 pt-4 border-t border-slate-100">
          <button
            onClick={() => setActiveEngineTab('fhir')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors flex items-center gap-1.5 ${
              activeEngineTab === 'fhir'
                ? 'bg-slate-900 text-white shadow-2xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>HL7 FHIR R4 Explorer</span>
          </button>

          <button
            onClick={() => setActiveEngineTab('hl7')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors flex items-center gap-1.5 ${
              activeEngineTab === 'hl7'
                ? 'bg-slate-900 text-white shadow-2xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Code className="w-3.5 h-3.5" />
            <span>HL7 v2 Message Engine</span>
          </button>

          <button
            onClick={() => setActiveEngineTab('encryption')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors flex items-center gap-1.5 ${
              activeEngineTab === 'encryption'
                ? 'bg-slate-900 text-white shadow-2xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Lock className="w-3.5 h-3.5 text-emerald-400" />
            <span>AES-256 PHI Vault</span>
          </button>
        </div>
      </div>

      {/* Tab 1: FHIR R4 Engine */}
      {activeEngineTab === 'fhir' && (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          
          {/* Left Column: Resource Navigation (1 Col) */}
          <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs space-y-3">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
              FHIR R4 Resources
            </div>
            <div className="space-y-1.5">
              <button
                onClick={() => setSelectedFhirResource('Bundle')}
                className={`w-full text-left p-2.5 rounded-lg border text-xs transition-colors flex items-center justify-between ${
                  selectedFhirResource === 'Bundle'
                    ? 'bg-slate-900 text-white font-semibold border-slate-900'
                    : 'hover:bg-slate-50 border-slate-200 text-slate-700'
                }`}
              >
                <div>
                  <div>Bundle (Collection)</div>
                  <div className="text-[10px] opacity-75 font-mono">Total: {fhirBundle.total} resources</div>
                </div>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => setSelectedFhirResource('Patient')}
                className={`w-full text-left p-2.5 rounded-lg border text-xs transition-colors flex items-center justify-between ${
                  selectedFhirResource === 'Patient'
                    ? 'bg-slate-900 text-white font-semibold border-slate-900'
                    : 'hover:bg-slate-50 border-slate-200 text-slate-700'
                }`}
              >
                <div>
                  <div>Patient Resource</div>
                  <div className="text-[10px] opacity-75 font-mono">{currentPatient.mrn}</div>
                </div>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => setSelectedFhirResource('Observations')}
                className={`w-full text-left p-2.5 rounded-lg border text-xs transition-colors flex items-center justify-between ${
                  selectedFhirResource === 'Observations'
                    ? 'bg-slate-900 text-white font-semibold border-slate-900'
                    : 'hover:bg-slate-50 border-slate-200 text-slate-700'
                }`}
              >
                <div>
                  <div>Vital Observations</div>
                  <div className="text-[10px] opacity-75 font-mono">LOINC 8867-4, 85354-9</div>
                </div>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="pt-4 border-t border-slate-100">
              <button
                onClick={handleDownloadFhirBundle}
                disabled={isExporting}
                className="w-full py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg flex items-center justify-center gap-2 transition-colors shadow-2xs"
              >
                <Download className="w-4 h-4" />
                <span>Export FHIR JSON Bundle</span>
              </button>
              {exportSuccess && (
                <p className="text-[11px] text-emerald-600 text-center mt-1.5 flex items-center justify-center gap-1">
                  <CheckCircle2 className="w-3 h-3" />
                  Bundle downloaded successfully
                </p>
              )}
            </div>
          </div>

          {/* Right Columns: JSON Viewer (3 Cols) */}
          <div className="lg:col-span-3 bg-slate-950 rounded-xl border border-slate-800 p-4 font-mono text-xs overflow-hidden flex flex-col shadow-md">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 text-slate-400">
              <span className="text-[11px] text-emerald-400">
                FHIR R4 JSON Schema Validation: VALID
              </span>
              <span className="text-[10px]">Content-Type: application/fhir+json</span>
            </div>
            
            <pre className="flex-1 overflow-x-auto overflow-y-auto max-h-[500px] text-slate-300 py-3 leading-relaxed text-[11px] font-mono">
              {JSON.stringify(
                selectedFhirResource === 'Bundle'
                  ? fhirBundle
                  : selectedFhirResource === 'Patient'
                  ? fhirPatient
                  : fhirObservations,
                null,
                2
              )}
            </pre>
          </div>

        </div>
      )}

      {/* Tab 2: HL7 v2 Message Engine */}
      {activeEngineTab === 'hl7' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* HL7 Message Preview & Controls */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900">HL7 v2.5.1 Pipe &amp; Hat Stream</h3>
                <p className="text-xs text-slate-500">Live generated message for clinical transmission</p>
              </div>
              <select
                value={hl7MessageType}
                onChange={e => {
                  setHl7MessageType(e.target.value as any);
                  setCustomHl7Input('');
                }}
                className="text-xs px-2.5 py-1.5 border border-slate-200 rounded-lg bg-slate-50"
              >
                <option value="SIU^S12">SIU^S12 (Appointment Notification)</option>
                <option value="ADT^A01">ADT^A01 (Admit / Visit Registration)</option>
                <option value="ORM^O01">ORM^O01 (Order Message)</option>
              </select>
            </div>

            <div className="relative">
              <label className="block text-[11px] font-bold uppercase text-slate-400 mb-1">
                Raw Pipe-Delimited HL7 Text
              </label>
              <textarea
                value={customHl7Input || generatedHl7}
                onChange={e => setCustomHl7Input(e.target.value)}
                rows={10}
                className="w-full text-[11px] font-mono p-3 bg-slate-900 text-emerald-400 rounded-lg border border-slate-800 focus:outline-hidden resize-none leading-relaxed"
              />
            </div>

            <div className="flex items-center justify-between pt-2">
              <span className="text-[11px] text-slate-500 font-mono">
                Encoding: ASCII (Hex 0D delimiter)
              </span>
              <button
                onClick={() => {
                  onLogAuditEvent(
                    'HL7_TRANSMIT',
                    `Transmitted HL7 v2.5.1 ${hl7MessageType} message for MRN ${currentPatient.mrn} to Epic Hospital Interface Engine.`
                  );
                  alert(`HL7 ${hl7MessageType} dispatched successfully via MLLP protocol.`);
                }}
                className="px-4 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 transition-colors flex items-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5 text-emerald-400" />
                <span>Transmit via MLLP to Epic/Cerner</span>
              </button>
            </div>
          </div>

          {/* Segment Parser Breakdown */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">HL7 Segment Breakdown &amp; Syntax Inspector</h3>
              <p className="text-xs text-slate-500">Real-time parser analyzing standard field definitions</p>
            </div>

            {parsedHl7 && (
              <div className="space-y-2.5 max-h-[460px] overflow-y-auto pr-1">
                {parsedHl7.segments.map((seg: any, idx: number) => (
                  <div key={idx} className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs">
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="font-bold font-mono text-slate-900 bg-white px-2 py-0.5 rounded border border-slate-200">
                        {seg.segment} Segment
                      </span>
                      <span className="text-[10px] font-mono text-slate-400">{seg.fields.length} Fields</span>
                    </div>
                    <div className="text-[11px] font-mono text-slate-600 break-all bg-white p-2 rounded border border-slate-100">
                      {seg.raw}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>
      )}

      {/* Tab 3: AES-256 PHI Cryptographic Vault */}
      {activeEngineTab === 'encryption' && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-900">FIPS 140-2 AES-256-GCM PHI Cryptographic Vault</h3>
                <span className="text-[11px] font-mono bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded border border-emerald-200">
                  Web Crypto API Active
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Demonstrates field-level authenticated symmetric encryption for Protected Health Information (PHI) at rest.
              </p>
            </div>

            <button
              onClick={runEncryptionDemo}
              disabled={isEncrypting}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg transition-colors"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isEncrypting ? 'animate-spin' : ''}`} />
              <span>Re-Encrypt with New 96-Bit IV</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Field 1: SSN */}
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-slate-900">Social Security Number (SSN)</span>
                <span className="text-[10px] font-mono text-emerald-700 bg-emerald-100 px-1.5 py-0.5 rounded">
                  AES-256-GCM
                </span>
              </div>
              <div className="text-xs font-mono">
                <span className="text-slate-400 block text-[10px]">PLAINTEXT:</span>
                <span className="font-semibold text-slate-800">{currentPatient.ssnMasked}</span>
              </div>
              {encryptedVault.ssn && (
                <div className="space-y-1 text-[11px] font-mono bg-white p-2.5 rounded border border-slate-200">
                  <div className="text-slate-500">CIPHERTEXT (Base64):</div>
                  <div className="text-slate-800 break-all">{encryptedVault.ssn.cipherTextBase64}</div>
                  <div className="text-slate-500 mt-1">IV (Hex): <span className="text-slate-700">{encryptedVault.ssn.ivHex}</span></div>
                </div>
              )}
              <button
                onClick={() => handleTestDecryption('ssn')}
                className="text-[11px] text-emerald-700 font-semibold hover:underline flex items-center gap-1 pt-1"
              >
                <Key className="w-3 h-3" />
                <span>Test Decrypt: {decryptedValues.ssn || 'Click to Decrypt'}</span>
              </button>
            </div>

            {/* Field 2: Date of Birth */}
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-slate-900">Date of Birth (DOB)</span>
                <span className="text-[10px] font-mono text-emerald-700 bg-emerald-100 px-1.5 py-0.5 rounded">
                  AES-256-GCM
                </span>
              </div>
              <div className="text-xs font-mono">
                <span className="text-slate-400 block text-[10px]">PLAINTEXT:</span>
                <span className="font-semibold text-slate-800">{currentPatient.dob}</span>
              </div>
              {encryptedVault.dob && (
                <div className="space-y-1 text-[11px] font-mono bg-white p-2.5 rounded border border-slate-200">
                  <div className="text-slate-500">CIPHERTEXT (Base64):</div>
                  <div className="text-slate-800 break-all">{encryptedVault.dob.cipherTextBase64}</div>
                  <div className="text-slate-500 mt-1">IV (Hex): <span className="text-slate-700">{encryptedVault.dob.ivHex}</span></div>
                </div>
              )}
              <button
                onClick={() => handleTestDecryption('dob')}
                className="text-[11px] text-emerald-700 font-semibold hover:underline flex items-center gap-1 pt-1"
              >
                <Key className="w-3 h-3" />
                <span>Test Decrypt: {decryptedValues.dob || 'Click to Decrypt'}</span>
              </button>
            </div>

            {/* Field 3: Address */}
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-slate-900">Physical Home Address</span>
                <span className="text-[10px] font-mono text-emerald-700 bg-emerald-100 px-1.5 py-0.5 rounded">
                  AES-256-GCM
                </span>
              </div>
              <div className="text-xs font-mono">
                <span className="text-slate-400 block text-[10px]">PLAINTEXT:</span>
                <span className="font-semibold text-slate-800">{currentPatient.address}</span>
              </div>
              {encryptedVault.address && (
                <div className="space-y-1 text-[11px] font-mono bg-white p-2.5 rounded border border-slate-200">
                  <div className="text-slate-500">CIPHERTEXT (Base64):</div>
                  <div className="text-slate-800 break-all">{encryptedVault.address.cipherTextBase64}</div>
                  <div className="text-slate-500 mt-1">IV (Hex): <span className="text-slate-700">{encryptedVault.address.ivHex}</span></div>
                </div>
              )}
              <button
                onClick={() => handleTestDecryption('address')}
                className="text-[11px] text-emerald-700 font-semibold hover:underline flex items-center gap-1 pt-1"
              >
                <Key className="w-3 h-3" />
                <span>Test Decrypt: {decryptedValues.address || 'Click to Decrypt'}</span>
              </button>
            </div>

            {/* Field 4: Clinical Diagnosis */}
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-slate-900">ICD-10 Diagnostic Findings</span>
                <span className="text-[10px] font-mono text-emerald-700 bg-emerald-100 px-1.5 py-0.5 rounded">
                  AES-256-GCM
                </span>
              </div>
              <div className="text-xs font-mono">
                <span className="text-slate-400 block text-[10px]">PLAINTEXT:</span>
                <span className="font-semibold text-slate-800">
                  {currentPatient.conditions.map(c => `${c.code}: ${c.name}`).join('; ')}
                </span>
              </div>
              {encryptedVault.conditions && (
                <div className="space-y-1 text-[11px] font-mono bg-white p-2.5 rounded border border-slate-200">
                  <div className="text-slate-500">CIPHERTEXT (Base64):</div>
                  <div className="text-slate-800 break-all">{encryptedVault.conditions.cipherTextBase64}</div>
                  <div className="text-slate-500 mt-1">IV (Hex): <span className="text-slate-700">{encryptedVault.conditions.ivHex}</span></div>
                </div>
              )}
              <button
                onClick={() => handleTestDecryption('conditions')}
                className="text-[11px] text-emerald-700 font-semibold hover:underline flex items-center gap-1 pt-1"
              >
                <Key className="w-3 h-3" />
                <span>Test Decrypt: {decryptedValues.conditions || 'Click to Decrypt'}</span>
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
