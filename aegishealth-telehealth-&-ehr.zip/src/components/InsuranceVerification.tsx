/**
 * ANSI ASC X12 EDI 270/271 Real-Time Insurance Eligibility Verification
 * Features:
 * - Real-Time Clearinghouse Query Engine (EDI 270 Inquiry & EDI 271 Benefit Response)
 * - Telehealth Copay, Specialist Copay, & Remaining Deductible Breakdown
 * - Prior Authorization Detection & Payer Directory
 * - Raw X12 EDI Segment Inspector with Printable Benefit Verification Certificate
 */

import React, { useState } from 'react';
import {
  CreditCard,
  CheckCircle,
  AlertCircle,
  Clock,
  Printer,
  FileText,
  Search,
  ArrowRight,
  ShieldCheck,
  RefreshCw,
  Info,
} from 'lucide-react';
import { PatientRecord, InsurancePolicy, UserSession } from '../types/telehealth';
import { verifyInsuranceEligibility, EdiVerificationResult } from '../services/insuranceEdiService';

interface InsuranceVerificationProps {
  currentSession: UserSession;
  patients: PatientRecord[];
  policies: Record<string, InsurancePolicy>;
  onLogAuditEvent: (action: any, details: string) => void;
}

export const InsuranceVerification: React.FC<InsuranceVerificationProps> = ({
  currentSession,
  patients,
  policies,
  onLogAuditEvent,
}) => {
  const [selectedPatientId, setSelectedPatientId] = useState<string>(patients[0].id);
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationResult, setVerificationResult] = useState<EdiVerificationResult | null>(null);
  const [activeEdiTab, setActiveEdiTab] = useState<'summary' | 'edi270' | 'edi271'>('summary');

  const currentPatient = patients.find(p => p.id === selectedPatientId) || patients[0];
  const currentPolicy = policies[currentPatient.id] || {
    id: 'ins-default',
    patientId: currentPatient.id,
    payerId: 'BCBS-GEN',
    payerName: 'National BlueCross PPO',
    planType: 'PPO',
    policyNumber: 'GEN892019',
    groupNumber: 'GRP-100',
    subscriberName: `${currentPatient.firstName} ${currentPatient.lastName}`,
    status: 'active',
    effectiveDate: '2026-01-01',
    expirationDate: '2026-12-31',
    copayPrimary: 20,
    copaySpecialist: 40,
    copayTelehealth: 20,
    deductibleAnnual: 1500,
    deductibleMet: 1200,
    outOfPocketMax: 4000,
    outOfPocketCurrent: 1400,
    priorAuthRequired: false,
    lastVerifiedTimestamp: new Date().toISOString(),
  };

  const handleRunVerification = async () => {
    setIsVerifying(true);
    try {
      const res = await verifyInsuranceEligibility(currentPatient, currentPolicy);
      setVerificationResult(res);
      onLogAuditEvent(
        'INSURANCE_270_QUERY',
        `EDI 270 real-time inquiry executed for patient ${currentPatient.mrn}. Response 271: ${res.coverageStatus} with ${res.payerName} (Control #: ${res.transactionControlNumber})`
      );
    } catch (err) {
      alert('Clearinghouse connection failed. Please retry.');
    } finally {
      setIsVerifying(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight text-slate-900">
                EDI 270/271 Real-Time Eligibility Verification
              </h1>
              <span className="flex items-center gap-1 text-[11px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                <CreditCard className="w-3.5 h-3.5" />
                ANSI ASC X12 005010X279A1
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Verify telehealth patient benefits, copay obligations, deductible remaining, and prior authorization requirements.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <select
              value={selectedPatientId}
              onChange={e => {
                setSelectedPatientId(e.target.value);
                setVerificationResult(null);
              }}
              className="text-xs px-3 py-1.5 rounded-lg border border-slate-300 bg-white font-medium text-slate-800"
            >
              {patients.map(p => (
                <option key={p.id} value={p.id}>
                  {p.firstName} {p.lastName} ({p.mrn})
                </option>
              ))}
            </select>

            <button
              onClick={handleRunVerification}
              disabled={isVerifying}
              className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors shadow-2xs disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-emerald-400 ${isVerifying ? 'animate-spin' : ''}`} />
              <span>{isVerifying ? 'Querying Payer...' : 'Transmit EDI 270'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid: Policy Card & Verification Results */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column: Payer & Policy Information (1 Col) */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Registered Insurance Policy
            </span>
            <span className="text-[10px] font-mono bg-emerald-50 text-emerald-700 px-1.5 py-0.5 rounded border border-emerald-100">
              {currentPolicy.status.toUpperCase()}
            </span>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <span className="text-[10px] text-slate-400 uppercase font-bold block">Payer Name</span>
              <span className="font-bold text-slate-900 text-sm">{currentPolicy.payerName}</span>
              <span className="text-[11px] text-slate-500 font-mono block">Payer ID: {currentPolicy.payerId}</span>
            </div>

            <div className="grid grid-cols-2 gap-2 font-mono">
              <div>
                <span className="text-[10px] text-slate-400 font-sans block">POLICY NUMBER</span>
                <span className="font-semibold text-slate-800">{currentPolicy.policyNumber}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 font-sans block">GROUP NUMBER</span>
                <span className="font-semibold text-slate-800">{currentPolicy.groupNumber}</span>
              </div>
            </div>

            <div>
              <span className="text-[10px] text-slate-400 uppercase font-bold block">Plan Category</span>
              <span className="text-slate-800 font-medium">{currentPolicy.planType} Comprehensive Coverage</span>
            </div>

            <div className="pt-2 border-t border-slate-100 text-[11px] text-slate-500 font-mono">
              Effective: {currentPolicy.effectiveDate} to {currentPolicy.expirationDate}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100">
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-2">
              <div className="flex items-center gap-1.5 font-semibold text-slate-700">
                <Info className="w-3.5 h-3.5 text-sky-600" />
                <span>Eligibility Engine Guidelines</span>
              </div>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                Clearinghouse pings check ASC X12 Service Type 30 (Telemedicine &amp; Health Benefit). Prior authorization checks flag specialty consult orders.
              </p>
            </div>
          </div>
        </div>

        {/* Right Columns: Verification Dashboard & EDI Inspector (2 Cols) */}
        <div className="lg:col-span-2 space-y-4">
          
          {/* Segmented Controls for Results vs Raw EDI */}
          <div className="bg-white rounded-xl border border-slate-200 p-2 flex items-center gap-2">
            <button
              onClick={() => setActiveEdiTab('summary')}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                activeEdiTab === 'summary' ? 'bg-slate-900 text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Benefit Summary &amp; Copays
            </button>
            <button
              onClick={() => setActiveEdiTab('edi270')}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                activeEdiTab === 'edi270' ? 'bg-slate-900 text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Raw EDI 270 (Inquiry)
            </button>
            <button
              onClick={() => setActiveEdiTab('edi271')}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                activeEdiTab === 'edi271' ? 'bg-slate-900 text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Raw EDI 271 (Response)
            </button>
          </div>

          {/* View 1: Benefit Summary Dashboard */}
          {activeEdiTab === 'summary' && (
            <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-5">
              
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-200">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-emerald-50 text-emerald-700 flex items-center justify-center">
                    <CheckCircle className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">
                      Coverage Confirmed: {verificationResult ? verificationResult.coverageStatus : 'VERIFIED ACTIVE'}
                    </h3>
                    <p className="text-[11px] text-slate-500">
                      Transaction Control Number: <span className="font-mono">{verificationResult?.transactionControlNumber || 'TCN849201948'}</span>
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => window.print()}
                  className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg flex items-center gap-1.5 transition-colors self-start sm:self-auto"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Eligibility Record</span>
                </button>
              </div>

              {/* Copay Breakdown Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-center">
                  <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Telehealth Copay</div>
                  <div className="text-2xl font-bold text-slate-900 mt-1 font-mono tabular-nums">
                    ${currentPolicy.copayTelehealth}.00
                  </div>
                  <div className="text-[10px] text-emerald-700 mt-0.5">In-Network Guaranteed</div>
                </div>

                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-center">
                  <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Specialist Copay</div>
                  <div className="text-2xl font-bold text-slate-900 mt-1 font-mono tabular-nums">
                    ${currentPolicy.copaySpecialist}.00
                  </div>
                  <div className="text-[10px] text-slate-500 mt-0.5">Cardiology/Pulmonology</div>
                </div>

                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-center col-span-2 sm:col-span-1">
                  <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Deductible Remaining</div>
                  <div className="text-2xl font-bold text-slate-900 mt-1 font-mono tabular-nums">
                    ${Math.max(0, currentPolicy.deductibleAnnual - currentPolicy.deductibleMet)}.00
                  </div>
                  <div className="text-[10px] text-slate-500 mt-0.5">Annual: ${currentPolicy.deductibleAnnual}</div>
                </div>
              </div>

              {/* Deductible Progress Bar */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-800">Annual Out-of-Pocket Maximum Progress</span>
                  <span className="font-mono text-slate-600">
                    ${currentPolicy.outOfPocketCurrent} / ${currentPolicy.outOfPocketMax} ({Math.round((currentPolicy.outOfPocketCurrent / currentPolicy.outOfPocketMax) * 100)}%)
                  </span>
                </div>
                <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
                  <div
                    className="bg-emerald-600 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${(currentPolicy.outOfPocketCurrent / currentPolicy.outOfPocketMax) * 100}%` }}
                  />
                </div>
              </div>

              {/* Prior Auth Notice */}
              {currentPolicy.priorAuthRequired ? (
                <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-xl flex items-start gap-2.5 text-xs text-amber-900">
                  <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <strong>Prior Authorization Required:</strong> This payer requires pre-certification for advanced outpatient diagnostic orders and specialty consultations.
                  </div>
                </div>
              ) : (
                <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl flex items-start gap-2.5 text-xs text-emerald-900">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <strong>Direct Telehealth Access:</strong> Prior authorization is waived for standard virtual clinical visits and medication maintenance.
                  </div>
                </div>
              )}

            </div>
          )}

          {/* View 2: Raw EDI 270 Payload */}
          {activeEdiTab === 'edi270' && (
            <div className="bg-slate-950 rounded-xl border border-slate-800 p-4 font-mono text-xs text-emerald-400">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-slate-400 text-[11px] mb-3">
                <span>ANSI ASC X12N 270 Eligibility Inquiry Transaction</span>
                <span>Segment Terminator: ~</span>
              </div>
              <pre className="overflow-x-auto text-[11px] leading-relaxed text-slate-300">
                {verificationResult?.rawEdi270 ||
`ISA*00*          *00*          *ZZ*AEGISHEALTH    *ZZ*BCBS-NY-001    *260928*1432*^*00501*849201948*0*P*:~
GS*HS*AEGISHEALTH*BCBS-NY-001*20260928*1432*1*X*005010X279A1~
ST*270*0001*005010X279A1~
BHT*0022*13*TCN849201948*20260928*1432~
HL*1**20*1~
NM1*PR*2*Empire BlueCross BlueShield of NY*****PI*BCBS-NY-001~
HL*2*1*21*1~
NM1*1P*1*CHEN*SARAH***MD*XX*1922039485~
HL*3*2*22*0~
NM1*IL*1*MILLER*JAMES****MI*XEH839201948~
DMG*D8*19820414*M~
DTP*291*D8*20260928~
EQ*30~
SE*13*0001~
GE*1*1~
IEA*1*849201948~`}
              </pre>
            </div>
          )}

          {/* View 3: Raw EDI 271 Payload */}
          {activeEdiTab === 'edi271' && (
            <div className="bg-slate-950 rounded-xl border border-slate-800 p-4 font-mono text-xs text-emerald-400">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-slate-400 text-[11px] mb-3">
                <span>ANSI ASC X12N 271 Eligibility Response Transaction</span>
                <span>EB Segment: Benefit Information</span>
              </div>
              <pre className="overflow-x-auto text-[11px] leading-relaxed text-slate-300">
                {verificationResult?.rawEdi271 ||
`ISA*00*          *00*          *ZZ*BCBS-NY-001    *ZZ*AEGISHEALTH    *260928*1432*^*00501*849201948*0*P*:~
GS*HB*BCBS-NY-001*AEGISHEALTH*20260928*1432*1*X*005010X279A1~
ST*271*0001*005010X279A1~
BHT*0022*11*TCN849201948*20260928*1432~
HL*1**20*1~
NM1*PR*2*Empire BlueCross BlueShield of NY*****PI*BCBS-NY-001~
HL*2*1*21*1~
NM1*1P*1*CHEN*SARAH***MD*XX*1922039485~
HL*3*2*22*0~
NM1*IL*1*MILLER*JAMES****MI*XEH839201948~
REF*6P*GRP-99201~
EB*1**30*PR*PPO*27*20.00*****Y~
EB*C**30***23*250.00*****Y~
EB*G**30***29*2320.00*****Y~
SE*14*0001~
GE*1*1~
IEA*1*849201948~`}
              </pre>
            </div>
          )}

        </div>

      </div>

    </div>
  );
};
