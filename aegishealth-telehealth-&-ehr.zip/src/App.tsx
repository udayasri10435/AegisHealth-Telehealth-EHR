/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navigation } from './components/Navigation';
import { VideoConsultRoom } from './components/VideoConsultRoom';
import { EPrescribeManager } from './components/EPrescribeManager';
import { EHRIntegration } from './components/EHRIntegration';
import { SchedulingManager } from './components/SchedulingManager';
import { InsuranceVerification } from './components/InsuranceVerification';
import { BAAWorkflows } from './components/BAAWorkflows';
import { AuditLogViewer } from './components/AuditLogViewer';
import { BreakGlassModal } from './components/BreakGlassModal';
import { KeyRotationModal } from './components/KeyRotationModal';

import {
  CURRENT_SESSIONS,
  MOCK_PATIENTS,
  MOCK_PROVIDERS,
  MOCK_APPOINTMENTS,
  MOCK_PRESCRIPTIONS,
  MOCK_PHARMACIES,
  MOCK_INSURANCE_POLICIES,
  MOCK_BAA_AGREEMENTS,
  MOCK_AUDIT_LOGS,
} from './data/mockData';

import {
  UserRole,
  UserSession,
  PatientRecord,
  ProviderRecord,
  AppointmentRecord,
  PrescriptionRecord,
  BAARecord,
  AuditLogEntry,
  AuditAction,
} from './types/telehealth';
import { computeSha256 } from './services/cryptoService';

export default function App() {
  // Navigation & Role State
  const [activeTab, setActiveTab] = useState<string>('video');
  const [currentSession, setCurrentSession] = useState<UserSession>(CURRENT_SESSIONS.physician);

  // Clinical & System State
  const [patients, setPatients] = useState<PatientRecord[]>(MOCK_PATIENTS);
  const [providers] = useState<ProviderRecord[]>(MOCK_PROVIDERS);
  const [appointments, setAppointments] = useState<AppointmentRecord[]>(MOCK_APPOINTMENTS);
  const [prescriptions, setPrescriptions] = useState<PrescriptionRecord[]>(MOCK_PRESCRIPTIONS);
  const [baaList, setBaaList] = useState<BAARecord[]>(MOCK_BAA_AGREEMENTS);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(MOCK_AUDIT_LOGS);

  // Contextual Selection
  const [selectedPatientId, setSelectedPatientId] = useState<string>(MOCK_PATIENTS[0].id);

  // Modals
  const [breakGlassOpen, setBreakGlassOpen] = useState(false);
  const [keyRotationOpen, setKeyRotationOpen] = useState(false);

  // Active appointment for video consult
  const activeAppointment = appointments.find(a => a.patientId === selectedPatientId) || appointments[0];
  const activePatient = patients.find(p => p.id === selectedPatientId) || patients[0];

  // Audit logger with SHA-256 tamper-evident hash chaining (§ 164.312(b))
  const handleLogAuditEvent = async (
    action: AuditAction,
    details: string,
    targetPatientId?: string,
    targetPatientMrn?: string
  ) => {
    const lastEntry = auditLogs[auditLogs.length - 1];
    const prevHash = lastEntry ? lastEntry.currentHash : '0000000000000000000000000000000000000000000000000000000000000000';
    const id = `aud-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const timestamp = new Date().toISOString();

    const payload = `${id}|${prevHash}|${action}|${timestamp}|${details}`;
    const currentHash = await computeSha256(payload);

    const newEntry: AuditLogEntry = {
      id,
      timestamp,
      userId: currentSession.id,
      userRole: currentSession.role,
      action,
      resourceType: 'ClinicalEncounter',
      resourceId: targetPatientId || activePatient.id,
      patientId: targetPatientId || activePatient.id,
      patientMrn: targetPatientMrn || activePatient.mrn,
      details,
      ipAddress: '198.51.100.42 (TLS 1.3 Client)',
      userAgent: 'AegisTelehealth-Web/3.4',
      status: action === 'BREAK_GLASS_ACCESS' ? 'break_glass_alert' : 'success',
      prevHash,
      currentHash,
    };

    setAuditLogs(prev => [...prev, newEntry]);
  };

  // Switch role between Physician, Patient, Admin, Compliance Officer
  const handleSwitchRole = (role: UserRole) => {
    const session = CURRENT_SESSIONS[role];
    if (session) {
      setCurrentSession(session);
      handleLogAuditEvent(
        'PHI_READ',
        `User switched active role to ${session.title} (${role}). RBAC profile updated.`
      );
    }
  };

  // SOAP Note saved from Video Consult
  const handleSaveSoapNote = (
    appointmentId: string,
    soap: { subjective: string; objective: string; assessment: string; plan: string; icd10: string }
  ) => {
    setAppointments(prev =>
      prev.map(a => {
        if (a.id === appointmentId) {
          return {
            ...a,
            clinicalNotes: {
              id: `soap-${Date.now()}`,
              appointmentId,
              providerId: currentSession.npi || '1922039485',
              timestamp: new Date().toISOString(),
              subjective: soap.subjective,
              objective: soap.objective,
              assessment: soap.assessment,
              plan: soap.plan,
              icd10Diagnosis: soap.icd10,
              signedByNpi: currentSession.npi || '1922039485',
            },
          };
        }
        return a;
      })
    );
  };

  // Add new prescription
  const handleAddPrescription = (newRx: PrescriptionRecord) => {
    setPrescriptions(prev => [newRx, ...prev]);
  };

  // Add new scheduled appointment
  const handleAddAppointment = (newAppt: AppointmentRecord) => {
    setAppointments(prev => [newAppt, ...prev]);
  };

  // Join consult from scheduler
  const handleJoinConsult = (appt: AppointmentRecord) => {
    setSelectedPatientId(appt.patientId);
    setActiveTab('video');
    handleLogAuditEvent(
      'CONSULT_START',
      `Physician launched video consult for appointment ${appt.id} (Patient: ${appt.patientName}).`
    );
  };

  // Quick jump from video consult to e-prescribe
  const handleNavigateToEprescribe = (patientId: string) => {
    setSelectedPatientId(patientId);
    setActiveTab('eprescribe');
  };

  // Update BAA agreement
  const handleUpdateBaa = (updated: BAARecord) => {
    setBaaList(prev => prev.map(b => (b.id === updated.id ? updated : b)));
  };

  // Emergency Break-Glass Execution
  const handleExecuteBreakGlass = (patient: PatientRecord, reason: string, category: string) => {
    handleLogAuditEvent(
      'BREAK_GLASS_ACCESS',
      `EMERGENCY BREAK-GLASS INVOKED by ${currentSession.name} (${currentSession.title}) for MRN ${patient.mrn}. Category: ${category}. Clinical Justification: "${reason}"`,
      patient.id,
      patient.mrn
    );
    setSelectedPatientId(patient.id);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col selection:bg-slate-900 selection:text-white">
      
      {/* Top Bar Contract Navigation */}
      <Navigation
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currentSession={currentSession}
        onSwitchRole={handleSwitchRole}
        onOpenBreakGlass={() => setBreakGlassOpen(true)}
        onOpenKeyRotation={() => setKeyRotationOpen(true)}
        isFipsActive={true}
      />

      {/* Main Clinical Viewport */}
      <main className="flex-1 pb-16">
        {activeTab === 'video' && (
          <VideoConsultRoom
            currentSession={currentSession}
            patient={activePatient}
            appointment={activeAppointment}
            onNavigateToEprescribe={handleNavigateToEprescribe}
            onSaveSoapNote={handleSaveSoapNote}
            onLogAuditEvent={handleLogAuditEvent}
          />
        )}

        {activeTab === 'eprescribe' && (
          <EPrescribeManager
            currentSession={currentSession}
            patients={patients}
            providers={providers}
            pharmacies={MOCK_PHARMACIES}
            prescriptions={prescriptions}
            activePatientId={selectedPatientId}
            onAddPrescription={handleAddPrescription}
            onLogAuditEvent={handleLogAuditEvent}
          />
        )}

        {activeTab === 'ehr' && (
          <EHRIntegration
            patients={patients}
            providers={providers}
            appointments={appointments}
            prescriptions={prescriptions}
            onLogAuditEvent={handleLogAuditEvent}
          />
        )}

        {activeTab === 'scheduling' && (
          <SchedulingManager
            currentSession={currentSession}
            patients={patients}
            providers={providers}
            appointments={appointments}
            onAddAppointment={handleAddAppointment}
            onJoinConsult={handleJoinConsult}
            onLogAuditEvent={handleLogAuditEvent}
          />
        )}

        {activeTab === 'insurance' && (
          <InsuranceVerification
            currentSession={currentSession}
            patients={patients}
            policies={MOCK_INSURANCE_POLICIES}
            onLogAuditEvent={handleLogAuditEvent}
          />
        )}

        {activeTab === 'baa' && (
          <BAAWorkflows
            currentSession={currentSession}
            baaList={baaList}
            onUpdateBaa={handleUpdateBaa}
            onLogAuditEvent={handleLogAuditEvent}
          />
        )}

        {activeTab === 'audit' && (
          <AuditLogViewer
            currentSession={currentSession}
            auditLogs={auditLogs}
          />
        )}
      </main>

      {/* Emergency Break-Glass Modal */}
      <BreakGlassModal
        isOpen={breakGlassOpen}
        onClose={() => setBreakGlassOpen(false)}
        currentSession={currentSession}
        patients={patients}
        onExecuteBreakGlass={handleExecuteBreakGlass}
      />

      {/* FIPS 140-2 Key Rotation Modal */}
      <KeyRotationModal
        isOpen={keyRotationOpen}
        onClose={() => setKeyRotationOpen(false)}
        onLogAuditEvent={handleLogAuditEvent}
      />

      {/* Minimal Footer */}
      <footer className="border-t border-slate-200 bg-white py-4 px-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-800">AegisHealth Telehealth &amp; EHR</span>
            <span aria-hidden="true">·</span>
            <span>HIPAA Security &amp; Privacy Rule Certified (45 CFR § 164)</span>
          </div>
          <div className="text-[11px] text-slate-400 font-mono">
            AES-256-GCM · TLS 1.3 · WebRTC SRTP · ONC Interoperability Ready
          </div>
        </div>
      </footer>

    </div>
  );
}
